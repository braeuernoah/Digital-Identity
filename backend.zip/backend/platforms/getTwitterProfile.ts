type Params = Record<string, never>

export type TwitterProfileData = {
  id: string
  name: string
  username: string
  description: string
  location: string
  profile_image_url: string
  public_metrics: {
    followers_count: number
    following_count: number
    tweet_count: number
  }
  verified: boolean
  created_at: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: TwitterProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "twitterOAuth"
  //    Base URL        : https://api.twitter.com
  //    Auth            : OAuth 2.0 (PKCE)
  //    Authorization URL: https://twitter.com/i/oauth2/authorize
  //    Access Token URL : https://api.twitter.com/2/oauth2/token
  //    Client ID/Secret : developer.twitter.com → Projects & Apps
  //    Scopes          : tweet.read users.read offline.access
  //
  // 2. Replace the return below with:
  //    const result = await twitterOAuth.get(
  //      '/2/users/me?user.fields=description,location,profile_image_url,public_metrics,verified,created_at'
  //    )
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'X/Twitter OAuth token expired. Please re-authenticate.' } }
  //    if (result.status === 429) return { data: null, error: { code: 'RATE_LIMIT', message: 'X/Twitter API rate limit reached. Try again later.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Twitter API error (${result.status})` } }
  //    return { data: (result.data as { data: TwitterProfileData }).data, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your X / Twitter account via OAuth 2.0 to sync your social profile.',
    },
  }
}
