type Params = Record<string, never>

export type SpotifyProfileData = {
  id: string
  display_name: string
  email: string
  country: string
  product: string
  followers: { total: number }
  images: { url: string; height: number | null; width: number | null }[]
  external_urls: { spotify: string }
  explicit_content: { filter_enabled: boolean; filter_locked: boolean }
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: SpotifyProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "spotifyOAuth"
  //    Base URL        : https://api.spotify.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://accounts.spotify.com/authorize
  //    Access Token URL : https://accounts.spotify.com/api/token
  //    Client ID/Secret : developer.spotify.com/dashboard
  //    Scopes          : user-read-email user-read-private
  //
  // 2. Replace the return below with:
  //    const result = await spotifyOAuth.get('/v1/me')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Spotify OAuth token expired. Please re-authenticate.' } }
  //    if (result.status === 403) return { data: null, error: { code: 'NOT_CONNECTED', message: 'Spotify account not connected. Authorize access to sync your profile.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Spotify API error (${result.status})` } }
  //    return { data: result.data as SpotifyProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your Spotify account via OAuth 2.0 to sync your music profile.',
    },
  }
}
