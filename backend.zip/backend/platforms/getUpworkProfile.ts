type Params = Record<string, never>

export type UpworkProfileData = {
  id: string
  profile_url: string
  name: string
  title: string
  description: string
  skills: string[]
  hourly_rate: string
  total_jobs: number
  total_hours: number
  feedback_score: number
  feedback_count: number
  member_since: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: UpworkProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "upworkOAuth"
  //    Base URL        : https://www.upwork.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://www.upwork.com/ab/account-security/oauth2/authorize
  //    Access Token URL : https://www.upwork.com/api/v3/oauth2/token
  //    Client ID/Secret : developers.upwork.com → My Apps
  //    Scopes          : read_contract read_general read_messages
  //
  // 2. Replace with:
  //    const result = await upworkOAuth.get('/api/profiles/v1/me/profile')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Upwork token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Upwork API ${result.status}` } }
  //    return { data: result.data?.profile as UpworkProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Upwork account to view freelancer profile data.' },
  }
}
