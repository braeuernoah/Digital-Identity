type Params = Record<string, never>

export type InstagramProfileData = {
  id: string
  username: string
  name: string
  biography: string
  followers_count: number
  follows_count: number
  media_count: number
  profile_picture_url: string
  website: string
  account_type: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: InstagramProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "instagramOAuth"
  //    Base URL        : https://graph.instagram.com
  //    Auth            : OAuth 2.0 (Facebook Login / Instagram Basic Display API)
  //    Authorization URL: https://api.instagram.com/oauth/authorize
  //    Access Token URL : https://api.instagram.com/oauth/access_token
  //    Client ID/Secret : developers.facebook.com → My Apps
  //    Scopes          : user_profile user_media
  //
  // 2. Replace with:
  //    const result = await instagramOAuth.get(
  //      '/me?fields=id,username,name,biography,followers_count,follows_count,media_count,profile_picture_url,website,account_type'
  //    )
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Instagram token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Instagram API ${result.status}` } }
  //    return { data: result.data as InstagramProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Instagram account to view profile data.' },
  }
}
