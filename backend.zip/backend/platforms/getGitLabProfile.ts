type Params = Record<string, never>

export type GitLabProfileData = {
  id: number
  username: string
  name: string
  email: string
  bio: string | null
  location: string | null
  website_url: string
  avatar_url: string
  created_at: string
  public_repos: number
  followers: number
  following: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: GitLabProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "gitlabOAuth"
  //    Base URL        : https://gitlab.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://gitlab.com/oauth/authorize
  //    Access Token URL : https://gitlab.com/oauth/token
  //    Client ID/Secret : gitlab.com → User Settings → Applications
  //    Scopes          : read_user
  //
  // 2. Replace with:
  //    const result = await gitlabOAuth.get('/api/v4/user')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'GitLab token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `GitLab API ${result.status}` } }
  //    return { data: result.data as GitLabProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your GitLab account to view repository data.' },
  }
}
