type Params = Record<string, never>

export type LinkedInProfileData = {
  id: string
  localizedFirstName: string
  localizedLastName: string
  localizedHeadline: string
  email: string
  vanityName: string
  location: string
  industry: string
  summary: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: LinkedInProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "linkedinOAuth"
  //    Base URL        : https://api.linkedin.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://www.linkedin.com/oauth/v2/authorization
  //    Access Token URL : https://www.linkedin.com/oauth/v2/accessToken
  //    Client ID/Secret : linkedin.com/developers → Create App
  //    Scopes          : r_liteprofile r_emailaddress
  //
  // 2. Replace the return below with:
  //    const [profileRes, emailRes] = await Promise.all([
  //      linkedinOAuth.get('/v2/me?projection=(id,localizedFirstName,localizedLastName,vanityName)'),
  //      linkedinOAuth.get('/v2/emailAddress?q=members&projection=(elements*(handle~))'),
  //    ])
  //    if (profileRes.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'LinkedIn OAuth token expired.' } }
  //    if (!profileRes.ok) return { data: null, error: { code: 'API_ERROR', message: `LinkedIn API error (${profileRes.status})` } }
  //    const email = emailRes.data?.elements?.[0]?.['handle~']?.emailAddress ?? ''
  //    return { data: { ...profileRes.data, email } as LinkedInProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your LinkedIn account via OAuth 2.0 to sync your professional profile.',
    },
  }
}
