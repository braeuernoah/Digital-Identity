// ─── Types ────────────────────────────────────────────────────────────────────
// PlatformSearchResult and SearchResponse are the canonical types for this
// function's output. The frontend mirrors them in /frontend/pages/data/searchTypes.ts
// so it never needs to import from the backend directory.

type Params = {
  query: string
}

type PlatformSearchResult = {
  name: string
  description: string
  settingsUrl: string
  settingsLabel: string
  profileUrl: string | null
  profileLabel: string | null
  logoInitials: string
  logoBg: string
  logoFg: string
  confidence: 'high' | 'medium' | 'low'
}

type SearchResponse =
  | { ok: true; platform: PlatformSearchResult }
  | { ok: false; reason: 'unknown_platform' | 'parse_error' | 'empty_query' }

// ─── System prompt ────────────────────────────────────────────────────────────

const SYSTEM = `You are a platform metadata expert for a deep-link account-maintenance directory.
When given a platform name, return ONLY a raw JSON object — no markdown fences, no backticks, no explanation, no extra text. Just the JSON.

Required schema:
{
  "name": "Official platform name (string)",
  "description": "One-line description, max 60 chars, focused on what users do with their account (string)",
  "settingsUrl": "The most direct URL to the platform's account settings or profile-editing page — must be a real, stable URL (string)",
  "settingsLabel": "Short action label for the settings button, max 20 chars (string)",
  "profileUrl": "URL specifically for editing the public-facing profile, null if it is the same as settingsUrl (string | null)",
  "profileLabel": "Short action label for the profile button, max 20 chars, null if profileUrl is null (string | null)",
  "logoInitials": "2-3 uppercase characters derived from the platform name (string)",
  "logoBg": "The platform's primary brand colour as a CSS hex string, e.g. #4285F4 (string)",
  "logoFg": "#ffffff or #000000 — whichever provides better contrast against logoBg (string)",
  "confidence": "high if you are certain the URLs are correct; medium if plausible but unverified; low if guessing (string)"
}

If you do not recognise the platform at all, return exactly: {"error":"unknown_platform"}
Never return anything other than a single JSON object.`

// ─── Handler ──────────────────────────────────────────────────────────────────

export default async function searchPlatform(req: {
  params: Params
  user: User
}): Promise<SearchResponse> {
  const query = (req.params.query ?? '').trim()

  if (!query) return { ok: false, reason: 'empty_query' }

  const result = await anthropic.text.generate({
    model: 'claude-haiku-4-5-20251001',
    systemMessage: SYSTEM,
    instruction: `Platform: ${query}`,
    temperature: 0.1,
  })

  const raw = result.data.queryData.data

  // Strip markdown code fences if the model wraps despite instructions
  const cleaned = raw
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```\s*$/, '')
    .trim()

  let parsed: Record<string, unknown>
  try {
    parsed = JSON.parse(cleaned) as Record<string, unknown>
  } catch {
    return { ok: false, reason: 'parse_error' }
  }

  if (parsed['error'] === 'unknown_platform') {
    return { ok: false, reason: 'unknown_platform' }
  }

  // Validate required fields exist
  const required = ['name', 'description', 'settingsUrl', 'settingsLabel', 'logoInitials', 'logoBg', 'logoFg', 'confidence']
  for (const field of required) {
    if (typeof parsed[field] !== 'string') {
      return { ok: false, reason: 'parse_error' }
    }
  }

  const platform: PlatformSearchResult = {
    name: String(parsed['name']).trim(),
    description: String(parsed['description']).trim(),
    settingsUrl: String(parsed['settingsUrl']).trim(),
    settingsLabel: String(parsed['settingsLabel']).trim() || 'Account Settings',
    profileUrl: typeof parsed['profileUrl'] === 'string' ? String(parsed['profileUrl']).trim() : null,
    profileLabel: typeof parsed['profileLabel'] === 'string' ? String(parsed['profileLabel']).trim() : null,
    logoInitials: String(parsed['logoInitials']).slice(0, 3).toUpperCase(),
    logoBg: String(parsed['logoBg']).trim(),
    logoFg: String(parsed['logoFg']).trim(),
    confidence: (parsed['confidence'] as PlatformSearchResult['confidence']) ?? 'medium',
  }

  return { ok: true, platform }
}
