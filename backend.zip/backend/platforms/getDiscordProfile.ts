type Params = Record<string, never>

export type DiscordProfileData = {
  id: string
  username: string
  global_name: string | null
  discriminator: string
  email: string
  verified: boolean
  bio: string
  avatar: string | null
  banner: string | null
  premium_type: number
  locale: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: DiscordProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "discordOAuth"
  //    Base URL        : https://discord.com/api
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://discord.com/api/oauth2/authorize
  //    Access Token URL : https://discord.com/api/oauth2/token
  //    Client ID/Secret : discord.com/developers/applications → New Application
  //    Scopes          : identify email
  //
  // 2. Replace the return below with:
  //    const result = await discordOAuth.get('/v10/users/@me')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Discord OAuth token expired. Please re-authenticate.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Discord API error (${result.status})` } }
  //    return { data: result.data as DiscordProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your Discord account via OAuth 2.0 to sync your community profile.',
    },
  }
}
