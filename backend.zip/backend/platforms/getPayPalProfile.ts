type Params = Record<string, never>

export type PayPalProfileData = {
  user_id: string
  sub: string
  email: string
  name: string
  given_name: string
  family_name: string
  verified: boolean
  account_type: string
  verified_account: boolean
  email_verified: boolean
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: PayPalProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "paypalOAuth"
  //    Base URL        : https://api-m.paypal.com (live) or https://api-m.sandbox.paypal.com (sandbox)
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://www.paypal.com/signin/authorize
  //    Access Token URL : https://api-m.paypal.com/v1/oauth2/token
  //    Client ID/Secret : developer.paypal.com → Dashboard → Apps & Credentials
  //    Scopes          : openid profile email
  //
  // 2. Replace with:
  //    const result = await paypalOAuth.get('/v1/identity/openidconnect/userinfo?schema=openid')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'PayPal token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `PayPal API ${result.status}` } }
  //    return { data: result.data as PayPalProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your PayPal account to view identity data.' },
  }
}
