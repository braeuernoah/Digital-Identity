type Params = Record<string, never>

export type ShopifyProfileData = {
  id: number
  name: string
  email: string
  domain: string
  myshopify_domain: string
  plan_name: string
  plan_display_name: string
  shop_owner: string
  currency: string
  country_code: string
  created_at: string
  product_count?: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: ShopifyProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // Shopify uses per-store OAuth 2.0 (install flow) or Admin API.
  // 1. Retool → Resources → Create REST API → name: "shopifyAdmin"
  //    Base URL        : https://{your-store}.myshopify.com
  //    Auth            : OAuth 2.0 or X-Shopify-Access-Token header
  //    Authorization URL: https://{store}/admin/oauth/authorize
  //    Access Token URL : https://{store}/admin/oauth/access_token
  //    Client ID/Secret : partners.shopify.com → Apps → Create App
  //    Scopes          : read_orders read_products read_customers
  //
  // 2. Replace with:
  //    const result = await shopifyAdmin.get('/admin/api/2024-01/shop.json')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Shopify token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Shopify API ${result.status}` } }
  //    return { data: result.data?.shop as ShopifyProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Shopify store to view shop data.' },
  }
}
