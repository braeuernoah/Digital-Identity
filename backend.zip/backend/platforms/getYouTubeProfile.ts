type Params = Record<string, never>

export type YouTubeProfileData = {
  id: string
  snippet: {
    title: string
    description: string
    customUrl: string
    publishedAt: string
    country: string
    thumbnails: { default: { url: string } }
  }
  statistics: {
    viewCount: string
    subscriberCount: string
    hiddenSubscriberCount: boolean
    videoCount: string
  }
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: YouTubeProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "youtubeOAuth"
  //    Base URL        : https://www.googleapis.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://accounts.google.com/o/oauth2/v2/auth
  //    Access Token URL : https://oauth2.googleapis.com/token
  //    Client ID/Secret : console.cloud.google.com → YouTube Data API v3
  //    Scopes          : https://www.googleapis.com/auth/youtube.readonly
  //
  // 2. Replace the return below with:
  //    const result = await youtubeOAuth.get(
  //      '/youtube/v3/channels?part=snippet,statistics&mine=true'
  //    )
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'YouTube token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `YouTube API ${result.status}` } }
  //    const channel = result.data?.items?.[0]
  //    if (!channel) return { data: null, error: { code: 'NOT_CONNECTED', message: 'No YouTube channel found.' } }
  //    return { data: channel as YouTubeProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your YouTube account to view channel data.',
    },
  }
}
