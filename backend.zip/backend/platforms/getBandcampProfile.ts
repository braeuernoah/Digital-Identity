type Params = Record<string, never>

export type BandcampProfileData = {
  id: number
  name: string
  subdomain: string
  url: string
  image_url: string
  bio: string
  location: string
  website: string
  followers: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: BandcampProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // Bandcamp provides a Fan API for authenticated users.
  // 1. Retool → Resources → Create REST API → name: "bandcampOAuth"
  //    Base URL        : https://bandcamp.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://bandcamp.com/oauth_login
  //    Access Token URL : https://bandcamp.com/oauth_token
  //    Client ID/Secret : bandcamp.com/developer → Apply for API Access
  //    Scopes          : fan_read
  //
  // 2. Replace with:
  //    const result = await bandcampOAuth.get('/api/fan/2/info')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Bandcamp token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Bandcamp API ${result.status}` } }
  //    return { data: result.data as BandcampProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Bandcamp account to view artist data.' },
  }
}
