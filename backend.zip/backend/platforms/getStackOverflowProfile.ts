type Params = Record<string, never>

export type StackOverflowProfileData = {
  user_id: number
  display_name: string
  reputation: number
  badge_counts: { bronze: number; silver: number; gold: number }
  location: string
  profile_image: string
  link: string
  is_employee: boolean
  question_count: number
  answer_count: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: StackOverflowProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "stackoverflowOAuth"
  //    Base URL        : https://api.stackexchange.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://stackoverflow.com/oauth
  //    Access Token URL : https://stackoverflow.com/oauth/access_token/json
  //    Client ID/Secret : stackapps.com → Apps → Register a New App
  //    Scopes          : (no specific scope needed for /me)
  //
  // 2. Replace with:
  //    const result = await stackoverflowOAuth.get('/2.3/me?site=stackoverflow&order=desc&sort=reputation&filter=default')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Stack Overflow token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Stack Overflow API ${result.status}` } }
  //    return { data: result.data?.items?.[0] as StackOverflowProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Stack Overflow account to view reputation data.' },
  }
}
