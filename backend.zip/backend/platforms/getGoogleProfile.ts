type Params = Record<string, never>

export type GoogleProfileData = {
  sub: string
  name: string
  given_name: string
  family_name: string
  email: string
  email_verified: boolean
  picture: string
  locale: string
  hd?: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: GoogleProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "googleOAuth"
  //    Base URL        : https://openidconnect.googleapis.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://accounts.google.com/o/oauth2/v2/auth
  //    Access Token URL : https://oauth2.googleapis.com/token
  //    Client ID/Secret : console.cloud.google.com → APIs & Services → Credentials
  //    Scopes          : openid email profile
  //
  // 2. Replace the return below with:
  //    const result = await googleOAuth.get('/v1/userinfo')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Google OAuth token expired. Please re-authenticate.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Google API error (${result.status})` } }
  //    return { data: result.data as GoogleProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your Google account via OAuth 2.0 to sync your identity profile.',
    },
  }
}
