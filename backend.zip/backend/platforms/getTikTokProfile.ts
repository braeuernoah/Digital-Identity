type Params = Record<string, never>

export type TikTokProfileData = {
  open_id: string
  union_id: string
  avatar_url: string
  display_name: string
  bio_description: string
  profile_deep_link: string
  follower_count: number
  following_count: number
  likes_count: number
  video_count: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: TikTokProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "tiktokOAuth"
  //    Base URL        : https://open.tiktokapis.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://www.tiktok.com/v2/auth/authorize/
  //    Access Token URL : https://open.tiktokapis.com/v2/oauth/token/
  //    Client ID/Secret : developers.tiktok.com → Manage Apps
  //    Scopes          : user.info.basic user.info.profile user.info.stats
  //
  // 2. Replace with:
  //    const result = await tiktokOAuth.post('/v2/user/info/', {
  //      body: JSON.stringify({ fields: ['open_id','display_name','bio_description','avatar_url','profile_deep_link','follower_count','following_count','likes_count','video_count'] })
  //    })
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'TikTok token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `TikTok API ${result.status}` } }
  //    return { data: result.data?.data?.user as TikTokProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your TikTok account to view creator data.' },
  }
}
