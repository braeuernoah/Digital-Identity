type Params = Record<string, never>

export type GitHubProfileData = {
  login: string
  name: string
  email: string | null
  bio: string | null
  location: string | null
  company: string | null
  avatar_url: string
  html_url: string
  followers: number
  following: number
  public_repos: number
  created_at: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: GitHubProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "githubOAuth"
  //    Base URL        : https://api.github.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://github.com/login/oauth/authorize
  //    Access Token URL : https://github.com/login/oauth/access_token
  //    Client ID/Secret : github.com/settings/developers → OAuth Apps
  //    Scopes          : read:user user:email
  //
  // 2. Replace the return below with:
  //    const result = await githubOAuth.get('/user')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'GitHub OAuth token expired. Please re-authenticate.' } }
  //    if (result.status === 403) return { data: null, error: { code: 'RATE_LIMIT', message: 'GitHub API rate limit reached. Try again later.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `GitHub API error (${result.status})` } }
  //    return { data: result.data as GitHubProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: {
      code: 'NOT_CONNECTED',
      message: 'Connect your GitHub account via OAuth 2.0 to sync your developer profile.',
    },
  }
}
