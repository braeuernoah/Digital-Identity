type Params = Record<string, never>

export type SoundCloudProfileData = {
  id: number
  username: string
  full_name: string
  description: string | null
  city: string | null
  country_code: string | null
  followers_count: number
  followings_count: number
  public_likes_count: number
  track_count: number
  permalink_url: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: SoundCloudProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "soundcloudOAuth"
  //    Base URL        : https://api.soundcloud.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://soundcloud.com/connect
  //    Access Token URL : https://api.soundcloud.com/oauth2/token
  //    Client ID/Secret : soundcloud.com/you/apps → Register a New App
  //    Scopes          : (default)
  //
  // 2. Replace with:
  //    const result = await soundcloudOAuth.get('/me')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'SoundCloud token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `SoundCloud API ${result.status}` } }
  //    return { data: result.data as SoundCloudProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your SoundCloud account to view track data.' },
  }
}
