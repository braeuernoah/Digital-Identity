type Params = Record<string, never>

export type FiverrProfileData = {
  username: string
  display_name: string
  description: string
  seller_level: string
  rating: number
  rating_count: number
  member_since: string
  profile_url: string
  gig_count: number
  response_rate: number
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: FiverrProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // Fiverr uses OAuth 2.0 via their Partner Program.
  // 1. Retool → Resources → Create REST API → name: "fiverrOAuth"
  //    Base URL        : https://api.fiverr.com
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://www.fiverr.com/oauth2/authorize
  //    Access Token URL : https://api.fiverr.com/oauth2/token
  //    Client ID/Secret : marketplace.fiverr.com/api → Developer Portal
  //    Scopes          : profile gig_management
  //
  // 2. Replace with:
  //    const result = await fiverrOAuth.get('/v1/me')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Fiverr token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Fiverr API ${result.status}` } }
  //    return { data: result.data as FiverrProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Fiverr account to view seller data.' },
  }
}
