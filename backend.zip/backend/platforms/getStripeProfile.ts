type Params = Record<string, never>

export type StripeProfileData = {
  id: string
  object: string
  business_profile: {
    name: string | null
    url: string | null
    support_email: string | null
  }
  email: string
  country: string
  default_currency: string
  created: number
  charges_enabled: boolean
  payouts_enabled: boolean
  details_submitted: boolean
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: StripeProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // Stripe uses Secret Keys (Bearer tokens), not standard OAuth 2.0.
  // 1. Retool → Resources → Create REST API → name: "stripeApi"
  //    Base URL        : https://api.stripe.com
  //    Auth            : Bearer Token
  //    Bearer Token    : sk_live_... (from dashboard.stripe.com → Developers → API Keys)
  //    Headers         : Stripe-Version: 2023-10-16
  //
  // 2. Replace with:
  //    const result = await stripeApi.get('/v1/account')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Stripe API key invalid or expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Stripe API ${result.status}` } }
  //    return { data: result.data as StripeProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Stripe account to view payment data.' },
  }
}
