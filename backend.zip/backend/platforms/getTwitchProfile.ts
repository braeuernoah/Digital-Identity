type Params = Record<string, never>

export type TwitchProfileData = {
  id: string
  login: string
  display_name: string
  email: string
  profile_image_url: string
  view_count: number
  created_at: string
  description: string
  broadcaster_type: string
}

type ProfileError = {
  code: 'TOKEN_EXPIRED' | 'API_ERROR' | 'NOT_CONNECTED' | 'RATE_LIMIT'
  message: string
}

type Response =
  | { data: TwitchProfileData; error: null }
  | { data: null; error: ProfileError }

export default async function (_req: { params: Params; user: User }): Promise<Response> {
  // ─── PRODUCTION SETUP ──────────────────────────────────────────────────────
  // 1. Retool → Resources → Create REST API → name: "twitchOAuth"
  //    Base URL        : https://api.twitch.tv
  //    Auth            : OAuth 2.0
  //    Authorization URL: https://id.twitch.tv/oauth2/authorize
  //    Access Token URL : https://id.twitch.tv/oauth2/token
  //    Client ID/Secret : dev.twitch.tv/console/apps
  //    Scopes          : user:read:email
  //
  // 2. Replace with:
  //    const result = await twitchOAuth.get('/helix/users')
  //    if (result.status === 401) return { data: null, error: { code: 'TOKEN_EXPIRED', message: 'Twitch token expired.' } }
  //    if (!result.ok) return { data: null, error: { code: 'API_ERROR', message: `Twitch API ${result.status}` } }
  //    return { data: result.data?.data?.[0] as TwitchProfileData, error: null }
  // ───────────────────────────────────────────────────────────────────────────
  return {
    data: null,
    error: { code: 'NOT_CONNECTED', message: 'Connect your Twitch account to view stream data.' },
  }
}
