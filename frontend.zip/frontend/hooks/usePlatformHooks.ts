import {
  useGetGitHubProfile,
  useGetGoogleProfile,
  useGetLinkedInProfile,
  useGetTwitterProfile,
  useGetDiscordProfile,
  useGetSpotifyProfile,
  useGetYouTubeProfile,
  useGetTwitchProfile,
  useGetInstagramProfile,
  useGetTikTokProfile,
  useGetGitLabProfile,
  useGetStackOverflowProfile,
  useGetUpworkProfile,
  useGetFiverrProfile,
  useGetSoundCloudProfile,
  useGetBandcampProfile,
  useGetBehanceProfile,
  useGetStripeProfile,
  useGetPayPalProfile,
  useGetShopifyProfile,
} from './backend/platforms'

export type PlatformHookHandle = {
  data: unknown
  loading: boolean
  error: string | null
  /** Trigger a (re-)fetch. Pass skipCache=true to bypass Retool's query cache. */
  trigger: (opts?: { skipCache?: boolean }) => Promise<unknown>
}

export type AllPlatformHooks = Record<string, PlatformHookHandle>

/**
 * Calls every platform hook unconditionally (required by Rules of Hooks),
 * then returns a stable keyed record so callers can access hooks by platform ID.
 * Only trigger the hooks you actually need — triggering all 20 on mount is wasteful.
 */
export function usePlatformHooks(): AllPlatformHooks {
  const github       = useGetGitHubProfile()
  const google       = useGetGoogleProfile()
  const linkedin     = useGetLinkedInProfile()
  const twitter      = useGetTwitterProfile()
  const discord      = useGetDiscordProfile()
  const spotify      = useGetSpotifyProfile()
  const youtube      = useGetYouTubeProfile()
  const twitch       = useGetTwitchProfile()
  const instagram    = useGetInstagramProfile()
  const tiktok       = useGetTikTokProfile()
  const gitlab       = useGetGitLabProfile()
  const stackoverflow = useGetStackOverflowProfile()
  const upwork       = useGetUpworkProfile()
  const fiverr       = useGetFiverrProfile()
  const soundcloud   = useGetSoundCloudProfile()
  const bandcamp     = useGetBandcampProfile()
  const behance      = useGetBehanceProfile()
  const stripe       = useGetStripeProfile()
  const paypal       = useGetPayPalProfile()
  const shopify      = useGetShopifyProfile()

  // Return a plain object. Callers should access individual hooks by ID.
  // Note: this object is recreated each render, which is fine — the individual
  // hook objects (github, google, …) are stable within the Retool hook lifecycle.
  return {
    github:        { data: github.data,        loading: github.loading,        error: github.error,        trigger: github.trigger        },
    google:        { data: google.data,        loading: google.loading,        error: google.error,        trigger: google.trigger        },
    linkedin:      { data: linkedin.data,      loading: linkedin.loading,      error: linkedin.error,      trigger: linkedin.trigger      },
    twitter:       { data: twitter.data,       loading: twitter.loading,       error: twitter.error,       trigger: twitter.trigger       },
    discord:       { data: discord.data,       loading: discord.loading,       error: discord.error,       trigger: discord.trigger       },
    spotify:       { data: spotify.data,       loading: spotify.loading,       error: spotify.error,       trigger: spotify.trigger       },
    youtube:       { data: youtube.data,       loading: youtube.loading,       error: youtube.error,       trigger: youtube.trigger       },
    twitch:        { data: twitch.data,        loading: twitch.loading,        error: twitch.error,        trigger: twitch.trigger        },
    instagram:     { data: instagram.data,     loading: instagram.loading,     error: instagram.error,     trigger: instagram.trigger     },
    tiktok:        { data: tiktok.data,        loading: tiktok.loading,        error: tiktok.error,        trigger: tiktok.trigger        },
    gitlab:        { data: gitlab.data,        loading: gitlab.loading,        error: gitlab.error,        trigger: gitlab.trigger        },
    stackoverflow: { data: stackoverflow.data, loading: stackoverflow.loading, error: stackoverflow.error, trigger: stackoverflow.trigger },
    upwork:        { data: upwork.data,        loading: upwork.loading,        error: upwork.error,        trigger: upwork.trigger        },
    fiverr:        { data: fiverr.data,        loading: fiverr.loading,        error: fiverr.error,        trigger: fiverr.trigger        },
    soundcloud:    { data: soundcloud.data,    loading: soundcloud.loading,    error: soundcloud.error,    trigger: soundcloud.trigger    },
    bandcamp:      { data: bandcamp.data,      loading: bandcamp.loading,      error: bandcamp.error,      trigger: bandcamp.trigger      },
    behance:       { data: behance.data,       loading: behance.loading,       error: behance.error,       trigger: behance.trigger       },
    stripe:        { data: stripe.data,        loading: stripe.loading,        error: stripe.error,        trigger: stripe.trigger        },
    paypal:        { data: paypal.data,        loading: paypal.loading,        error: paypal.error,        trigger: paypal.trigger        },
    shopify:       { data: shopify.data,       loading: shopify.loading,       error: shopify.error,       trigger: shopify.trigger       },
  }
}
