// Legacy entry-point — all logic has been migrated to Directory.tsx
export { default } from './Directory'
