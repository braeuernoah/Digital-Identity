import { useState, useMemo, useCallback } from 'react'
import {
  LayoutGrid,
  Compass,
  Plus,
  Search,
  X,
  Layers,
  CheckSquare,
  Trash2,
} from 'lucide-react'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Badge } from '../lib/shadcn/badge'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../lib/shadcn/tabs'
import { Separator } from '../lib/shadcn/separator'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../lib/shadcn/tooltip'
import { PlatformCard } from './ui/PlatformCard'
import { AddCustomPlatformDialog } from './ui/AddCustomPlatformDialog'
import { PlatformSearchDialog } from './ui/PlatformSearchDialog'
import { RoadmapModal } from './ui/RoadmapModal'
import { DonationBanner } from './ui/DonationBanner'
import {
  PLATFORMS,
  PLATFORMS_BY_ID,
  type Platform,
  type IndustryId,
} from './data/platformRegistry'
import { INDUSTRIES, INDUSTRIES_BY_ID } from './data/industryConfig'
import {
  loadActivePlatformIds,
  saveActivePlatformIds,
  loadCustomPlatforms,
  saveCustomPlatforms,
} from './data/directoryStore'

// ─── State helpers ────────────────────────────────────────────────────────────

type SetState<T> = (value: T | ((prev: T) => T)) => void

function usePersistedSet(loader: () => string[]): [string[], SetState<string[]>] {
  const [ids, setIds] = useState<string[]>(loader)
  const update: SetState<string[]> = useCallback(
    (value) => {
      setIds(prev => {
        const next = typeof value === 'function' ? value(prev) : value
        saveActivePlatformIds(next)
        return next
      })
    },
    [],
  )
  return [ids, update]
}

// ─── Dashboard Header ─────────────────────────────────────────────────────────

function DashboardHeader({
  activeCount,
  searchQuery,
  onSearchChange,
  onAddCustom,
  onSearchOpen,
}: {
  activeCount: number
  searchQuery: string
  onSearchChange: (q: string) => void
  onAddCustom: () => void
  onSearchOpen: () => void
}) {
  return (
    <div className="border-b bg-background sticky top-0 z-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex h-14 items-center justify-between gap-3">
          {/* Brand */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Layers className="h-4 w-4" />
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <p className="text-sm font-semibold leading-none text-foreground">
                  Profile Directory
                </p>
                <span className="rounded bg-primary/10 px-1 py-0.5 text-[9px] font-semibold text-primary leading-none tracking-wide">
                  v1.0.0
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground leading-none mt-0.5">
                Deep-Link Account Maintenance
              </p>
            </div>
          </div>

          {/* Search */}
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Search platforms…"
              className="h-8 pl-8 text-xs"
              value={searchQuery}
              onChange={e => onSearchChange(e.target.value)}
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-3 w-3" />
              </button>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 shrink-0">
            <RoadmapModal />
            {activeCount > 0 && (
              <Badge variant="secondary" className="text-xs px-2">
                {activeCount} active
              </Badge>
            )}
            <Button
              size="sm"
              variant="outline"
              className="h-8 gap-1.5 text-xs"
              onClick={onSearchOpen}
            >
              <Search className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Discover</span>
            </Button>
            <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={onAddCustom}>
              <Plus className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Add Custom</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Industry Quick-Load Strip ────────────────────────────────────────────────

function IndustryQuickLoad({
  onLoadIndustry,
}: {
  onLoadIndustry: (industryId: IndustryId) => void
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {INDUSTRIES.map(ind => (
        <button
          key={ind.id}
          onClick={() => onLoadIndustry(ind.id)}
          className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1 text-xs font-medium text-foreground transition-colors hover:bg-accent hover:border-border/80"
        >
          <span>{ind.icon}</span>
          {ind.shortName}
        </button>
      ))}
    </div>
  )
}

// ─── Empty Dashboard State ────────────────────────────────────────────────────

function EmptyDashboard({ onExplore }: { onExplore: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed bg-card px-6 py-16 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
        <LayoutGrid className="h-6 w-6 text-muted-foreground" />
      </div>
      <h3 className="text-base font-semibold text-foreground">Your dashboard is empty</h3>
      <p className="mt-1 max-w-xs text-sm text-muted-foreground">
        Load a preset industry set or browse all platforms to build your curated maintenance
        dashboard.
      </p>
      <div className="mt-5 flex gap-2">
        <Button size="sm" onClick={onExplore} className="gap-1.5">
          <Compass className="h-4 w-4" />
          Browse Platforms
        </Button>
      </div>
    </div>
  )
}

// ─── Platform Grid ────────────────────────────────────────────────────────────

function PlatformGrid({
  platforms,
  activeIds,
  showToggle,
  onAdd,
  onRemove,
}: {
  platforms: Platform[]
  activeIds: Set<string>
  showToggle: boolean
  onAdd: (id: string) => void
  onRemove: (id: string) => void
}) {
  if (platforms.length === 0) {
    return (
      <div className="col-span-full rounded-xl border border-dashed bg-card py-10 text-center text-sm text-muted-foreground">
        No platforms match your search.
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {platforms.map(platform => (
        <PlatformCard
          key={platform.id}
          platform={platform}
          isActive={activeIds.has(platform.id)}
          showToggle={showToggle}
          onAdd={() => onAdd(platform.id)}
          onRemove={() => onRemove(platform.id)}
        />
      ))}
    </div>
  )
}

// ─── Directory ────────────────────────────────────────────────────────────────

export default function Directory() {
  // ── Persisted state ────────────────────────────────────────────────────────
  const [activePlatformIds, setActivePlatformIds] = usePersistedSet(loadActivePlatformIds)
  const [customPlatforms, setCustomPlatforms] = useState<Platform[]>(loadCustomPlatforms)

  // ── Ephemeral UI state ─────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState<'dashboard' | 'explore'>('dashboard')
  const [exploreIndustry, setExploreIndustry] = useState<IndustryId>('creators')
  const [searchQuery, setSearchQuery] = useState('')
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [platformSearchOpen, setPlatformSearchOpen] = useState(false)

  // ── Derived lookup ─────────────────────────────────────────────────────────
  const allPlatformsById = useMemo<Record<string, Platform>>(() => {
    const map: Record<string, Platform> = { ...PLATFORMS_BY_ID }
    for (const p of customPlatforms) map[p.id] = p
    return map
  }, [customPlatforms])

  const activeSet = useMemo(() => new Set(activePlatformIds), [activePlatformIds])

  const allPlatforms = useMemo<Platform[]>(
    () => [...PLATFORMS, ...customPlatforms],
    [customPlatforms],
  )

  // ── Dashboard platforms (filtered + searched) ──────────────────────────────
  const dashboardPlatforms = useMemo<Platform[]>(() => {
    const q = searchQuery.toLowerCase()
    return activePlatformIds
      .map(id => allPlatformsById[id])
      .filter((p): p is Platform => p !== undefined)
      .filter(p => !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
  }, [activePlatformIds, allPlatformsById, searchQuery])

  // ── Explore platforms (by industry + searched) ─────────────────────────────
  const explorePlatforms = useMemo<Platform[]>(() => {
    const q = searchQuery.toLowerCase()
    return allPlatforms
      .filter(p => p.industry === exploreIndustry)
      .filter(p => !q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
  }, [allPlatforms, exploreIndustry, searchQuery])

  // ── Handlers ───────────────────────────────────────────────────────────────

  const handleAdd = useCallback((id: string) => {
    setActivePlatformIds(prev => (prev.includes(id) ? prev : [...prev, id]))
  }, [setActivePlatformIds])

  const handleRemove = useCallback((id: string) => {
    setActivePlatformIds(prev => prev.filter(x => x !== id))
  }, [setActivePlatformIds])

  const handleLoadIndustry = useCallback((industryId: IndustryId) => {
    const industry = INDUSTRIES_BY_ID[industryId]
    const toAdd = industry.platformIds
    setActivePlatformIds(prev => {
      const merged = [...prev]
      for (const id of toAdd) {
        if (!merged.includes(id)) merged.push(id)
      }
      return merged
    })
  }, [setActivePlatformIds])

  const handleClearAll = useCallback(() => {
    setActivePlatformIds([])
  }, [setActivePlatformIds])

  const handleAddCustomPlatform = useCallback((platform: Platform) => {
    setCustomPlatforms(prev => {
      const next = [...prev, platform]
      saveCustomPlatforms(next)
      return next
    })
    setActivePlatformIds(prev => [...prev, platform.id])
  }, [setActivePlatformIds])

  const handleRemoveCustomPlatform = useCallback((id: string) => {
    setCustomPlatforms(prev => {
      const next = prev.filter(p => p.id !== id)
      saveCustomPlatforms(next)
      return next
    })
    setActivePlatformIds(prev => prev.filter(x => x !== id))
  }, [setActivePlatformIds])

  const currentIndustry = INDUSTRIES_BY_ID[exploreIndustry]

  return (
    <TooltipProvider delayDuration={300}>
      <div className="min-h-screen bg-background text-foreground">
        {/* ── Header ── */}
        <DashboardHeader
          activeCount={activePlatformIds.length}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onAddCustom={() => setAddDialogOpen(true)}
          onSearchOpen={() => setPlatformSearchOpen(true)}
        />

        {/* ── Main Tabs ── */}
        <div className="mx-auto max-w-7xl px-4 pb-16 pt-4 sm:px-6">
          <Tabs
            value={activeTab}
            onValueChange={v => setActiveTab(v as typeof activeTab)}
            className="space-y-6"
          >
            <div className="flex items-center justify-between gap-4">
              <TabsList className="h-9">
                <TabsTrigger value="dashboard" className="gap-1.5 text-xs">
                  <LayoutGrid className="h-3.5 w-3.5" />
                  My Dashboard
                  {activePlatformIds.length > 0 && (
                    <span className="ml-0.5 rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] font-medium text-primary leading-none">
                      {activePlatformIds.length}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="explore" className="gap-1.5 text-xs">
                  <Compass className="h-3.5 w-3.5" />
                  Explore
                </TabsTrigger>
              </TabsList>

              {/* Dashboard toolbar */}
              {activeTab === 'dashboard' && activePlatformIds.length > 0 && (
                <div className="flex items-center gap-2">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 gap-1.5 text-xs text-muted-foreground hover:text-destructive"
                        onClick={handleClearAll}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span className="hidden sm:inline">Clear All</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Remove all platforms from your dashboard</TooltipContent>
                  </Tooltip>
                </div>
              )}
            </div>

            {/* ══════════════════════ MY DASHBOARD ══════════════════════ */}
            <TabsContent value="dashboard" className="space-y-6">
              {/* Industry preset loader */}
              <div className="rounded-xl border bg-card p-4">
                <p className="mb-3 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Load a preset industry set
                </p>
                <IndustryQuickLoad onLoadIndustry={handleLoadIndustry} />
              </div>

              <Separator />

              {/* Platform grid or empty state */}
              {dashboardPlatforms.length > 0 ? (
                <>
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-foreground">
                      Your Platforms
                      <span className="ml-2 text-xs font-normal text-muted-foreground">
                        — click any link to open your account settings
                      </span>
                    </h2>
                  </div>
                  <PlatformGrid
                    platforms={dashboardPlatforms}
                    activeIds={activeSet}
                    showToggle={false}
                    onAdd={handleAdd}
                    onRemove={p => {
                      const isCustom = customPlatforms.some(c => c.id === p)
                      if (isCustom) handleRemoveCustomPlatform(p)
                      else handleRemove(p)
                    }}
                  />
                </>
              ) : activePlatformIds.length === 0 ? (
                <EmptyDashboard onExplore={() => setActiveTab('explore')} />
              ) : (
                <div className="py-8 text-center text-sm text-muted-foreground">
                  No platforms match "{searchQuery}"
                </div>
              )}
            </TabsContent>

            {/* ══════════════════════ EXPLORE ══════════════════════ */}
            <TabsContent value="explore" className="space-y-5">
              {/* Industry tabs */}
              <div className="rounded-xl border bg-card p-1">
                <div className="flex flex-wrap gap-1">
                  {INDUSTRIES.map(ind => (
                    <button
                      key={ind.id}
                      onClick={() => setExploreIndustry(ind.id)}
                      className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                        exploreIndustry === ind.id
                          ? 'bg-primary text-primary-foreground shadow-sm'
                          : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                      }`}
                    >
                      <span>{ind.icon}</span>
                      <span className="hidden sm:inline">{ind.shortName}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Industry description */}
              <div
                className={`rounded-xl bg-gradient-to-r ${currentIndustry.gradientFrom} ${currentIndustry.gradientTo} p-4 border`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl" role="img" aria-label={currentIndustry.name}>
                    {currentIndustry.icon}
                  </span>
                  <div>
                    <h2 className="text-sm font-semibold text-foreground">
                      {currentIndustry.name}
                    </h2>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {currentIndustry.description}
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {explorePlatforms.length} platform
                        {explorePlatforms.length !== 1 ? 's' : ''}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 gap-1 text-xs bg-background/80"
                        onClick={() => {
                          handleLoadIndustry(exploreIndustry)
                          setActiveTab('dashboard')
                        }}
                      >
                        <CheckSquare className="h-3 w-3" />
                        Add All to Dashboard
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Platform grid with toggle */}
              <PlatformGrid
                platforms={explorePlatforms}
                activeIds={activeSet}
                showToggle
                onAdd={handleAdd}
                onRemove={handleRemove}
              />
            </TabsContent>
          </Tabs>
        </div>

        {/* ── Custom Platform Dialog ── */}
        <AddCustomPlatformDialog
          open={addDialogOpen}
          onOpenChange={setAddDialogOpen}
          onAdd={handleAddCustomPlatform}
        />

        {/* ── Platform Search Dialog ── */}
        <PlatformSearchDialog
          open={platformSearchOpen}
          onOpenChange={setPlatformSearchOpen}
          onAdd={handleAddCustomPlatform}
        />
      </div>

      {/* ── Donation Banner ── */}
      <DonationBanner />
    </TooltipProvider>
  )
}
