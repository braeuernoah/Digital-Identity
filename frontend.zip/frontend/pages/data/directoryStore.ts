import type { Platform } from './platformRegistry'

// ─── Storage Keys ─────────────────────────────────────────────────────────────

const KEYS = {
  activePlatformIds: 'dld_activePlatforms_v2',
  customPlatforms: 'dld_customPlatforms_v2',
} as const

// ─── Generic helpers ──────────────────────────────────────────────────────────

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw !== null ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* storage unavailable — silently skip */
  }
}

// ─── Active Platform IDs ──────────────────────────────────────────────────────

export function loadActivePlatformIds(): string[] {
  return readJson<string[]>(KEYS.activePlatformIds, [])
}

export function saveActivePlatformIds(ids: string[]): void {
  writeJson(KEYS.activePlatformIds, ids)
}

// ─── Custom Platforms ─────────────────────────────────────────────────────────

export function loadCustomPlatforms(): Platform[] {
  return readJson<Platform[]>(KEYS.customPlatforms, [])
}

export function saveCustomPlatforms(platforms: Platform[]): void {
  writeJson(KEYS.customPlatforms, platforms)
}

// ─── Custom Platform Builder ──────────────────────────────────────────────────

export type CustomPlatformInput = {
  name: string
  industry: Platform['industry']
  settingsUrl: string
  description?: string
  logoInitials?: string
}

const CUSTOM_LOGO_COLORS: Array<{ bg: string; fg: string }> = [
  { bg: '#6366F1', fg: '#ffffff' },
  { bg: '#EC4899', fg: '#ffffff' },
  { bg: '#14B8A6', fg: '#000000' },
  { bg: '#F59E0B', fg: '#000000' },
  { bg: '#10B981', fg: '#000000' },
  { bg: '#3B82F6', fg: '#ffffff' },
  { bg: '#8B5CF6', fg: '#ffffff' },
  { bg: '#EF4444', fg: '#ffffff' },
]

let _colorIndex = 0

export function buildCustomPlatform(input: CustomPlatformInput): Platform {
  const color = CUSTOM_LOGO_COLORS[_colorIndex % CUSTOM_LOGO_COLORS.length]
  _colorIndex++

  const initials =
    input.logoInitials?.trim().slice(0, 3).toUpperCase() ||
    input.name
      .split(/\s+/)
      .slice(0, 2)
      .map(w => w[0] ?? '')
      .join('')
      .toUpperCase() ||
    '?'

  return {
    id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    name: input.name.trim(),
    industry: input.industry,
    description: input.description?.trim() || 'Custom platform',
    logoInitials: initials,
    logoBg: color?.bg ?? '#6366F1',
    logoFg: color?.fg ?? '#ffffff',
    settingsUrl: input.settingsUrl.trim(),
    settingsLabel: 'Open Settings',
    isCustom: true,
  }
}
