// ─── Shared Search Types ──────────────────────────────────────────────────────
// Defined here (frontend-side) so the search dialog does NOT need to import
// from /backend — which would pull backend-only globals into the frontend compiler.

export type PlatformSearchResult = {
  name: string
  description: string
  settingsUrl: string
  settingsLabel: string
  profileUrl: string | null
  profileLabel: string | null
  logoInitials: string
  logoBg: string
  logoFg: string
  confidence: 'high' | 'medium' | 'low'
}

export type SearchResponse =
  | { ok: true; platform: PlatformSearchResult }
  | { ok: false; reason: 'unknown_platform' | 'parse_error' | 'empty_query' }
