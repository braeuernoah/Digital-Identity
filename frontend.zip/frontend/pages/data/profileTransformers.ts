import { TransformedProfile, formatCount } from './platformConfig'
import type {
  GitHubProfileData,
  GoogleProfileData,
  LinkedInProfileData,
  TwitterProfileData,
  DiscordProfileData,
  SpotifyProfileData,
  YouTubeProfileData,
  TwitchProfileData,
  InstagramProfileData,
  TikTokProfileData,
  GitLabProfileData,
  StackOverflowProfileData,
  UpworkProfileData,
  FiverrProfileData,
  SoundCloudProfileData,
  BandcampProfileData,
  BehanceProfileData,
  StripeProfileData,
  PayPalProfileData,
  ShopifyProfileData,
} from './profileTypes'

// ─── Individual transformers ───────────────────────────────────────────────────

function transformGitHub(d: GitHubProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.login,
    subtitle: `@${d.login}`,
    fields: [
      { label: 'Email', value: d.email ?? 'Not public', sensitive: true },
      { label: 'Bio', value: d.bio ?? '—' },
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Company', value: d.company ?? '—' },
      { label: 'Profile', value: d.html_url, mono: true },
    ],
    stats: [
      { label: 'Repos', value: formatCount(d.public_repos) },
      { label: 'Followers', value: formatCount(d.followers) },
      { label: 'Following', value: formatCount(d.following) },
    ],
  }
}

function transformGoogle(d: GoogleProfileData): TransformedProfile {
  return {
    displayName: d.name,
    subtitle: d.email,
    fields: [
      { label: 'Email', value: d.email, sensitive: true },
      { label: 'First', value: d.given_name ?? '—' },
      { label: 'Last', value: d.family_name ?? '—' },
      { label: 'Locale', value: d.locale ?? '—' },
      { label: 'Verified', value: d.email_verified ? 'Yes ✓' : 'No' },
    ],
    stats: [],
  }
}

function transformLinkedIn(d: LinkedInProfileData): TransformedProfile {
  return {
    displayName: `${d.localizedFirstName ?? ''} ${d.localizedLastName ?? ''}`.trim(),
    subtitle: `linkedin.com/in/${d.vanityName ?? ''}`,
    fields: [
      { label: 'Headline', value: d.localizedHeadline ?? '—' },
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Industry', value: d.industry ?? '—' },
    ],
    stats: [],
  }
}

function transformTwitter(d: TwitterProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.username,
    subtitle: `@${d.username}`,
    fields: [
      { label: 'Bio', value: d.description ?? '—' },
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Verified', value: d.verified ? 'Yes ✓' : 'No' },
    ],
    stats: [
      { label: 'Followers', value: formatCount(d.public_metrics?.followers_count ?? 0) },
      { label: 'Following', value: formatCount(d.public_metrics?.following_count ?? 0) },
      { label: 'Tweets', value: formatCount(d.public_metrics?.tweet_count ?? 0) },
    ],
  }
}

function transformDiscord(d: DiscordProfileData): TransformedProfile {
  const nitroLabel: Record<number, string> = { 0: 'None', 1: 'Nitro Classic', 2: 'Nitro', 3: 'Nitro Basic' }
  return {
    displayName: d.global_name ?? d.username,
    subtitle: `@${d.username}`,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Bio', value: d.bio ?? '—' },
      { label: 'Locale', value: d.locale ?? '—' },
      { label: 'Nitro', value: nitroLabel[d.premium_type] ?? 'Unknown' },
      { label: 'Verified', value: d.verified ? 'Yes ✓' : 'No' },
    ],
    stats: [],
  }
}

function transformSpotify(d: SpotifyProfileData): TransformedProfile {
  const plan = d.product ? d.product.charAt(0).toUpperCase() + d.product.slice(1) : '—'
  return {
    displayName: d.display_name ?? d.id,
    subtitle: d.id,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Country', value: d.country ?? '—' },
      { label: 'Plan', value: plan },
      { label: 'Profile', value: d.external_urls?.spotify ?? '—', mono: true },
    ],
    stats: [{ label: 'Followers', value: formatCount(d.followers?.total ?? 0) }],
  }
}

function transformYouTube(d: YouTubeProfileData): TransformedProfile {
  return {
    displayName: d.snippet?.title ?? d.id,
    subtitle: d.snippet?.customUrl ? `youtube.com/${d.snippet.customUrl}` : d.id,
    fields: [
      { label: 'Description', value: d.snippet?.description ?? '—' },
      { label: 'Country', value: d.snippet?.country ?? '—' },
      { label: 'Published', value: d.snippet?.publishedAt ? new Date(d.snippet.publishedAt).getFullYear().toString() : '—' },
    ],
    stats: [
      { label: 'Subscribers', value: d.statistics?.hiddenSubscriberCount ? 'Hidden' : formatCount(parseInt(d.statistics?.subscriberCount ?? '0', 10)) },
      { label: 'Views', value: formatCount(parseInt(d.statistics?.viewCount ?? '0', 10)) },
      { label: 'Videos', value: formatCount(parseInt(d.statistics?.videoCount ?? '0', 10)) },
    ],
  }
}

function transformTwitch(d: TwitchProfileData): TransformedProfile {
  return {
    displayName: d.display_name ?? d.login,
    subtitle: `twitch.tv/${d.login ?? ''}`,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Bio', value: d.description ?? '—' },
      { label: 'Type', value: d.broadcaster_type ? d.broadcaster_type || 'Viewer' : '—' },
    ],
    stats: [{ label: 'Views', value: formatCount(d.view_count ?? 0) }],
  }
}

function transformInstagram(d: InstagramProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.username,
    subtitle: `@${d.username ?? ''}`,
    fields: [
      { label: 'Bio', value: d.biography ?? '—' },
      { label: 'Website', value: d.website ?? '—', mono: true },
      { label: 'Account', value: d.account_type ?? '—' },
    ],
    stats: [
      { label: 'Followers', value: formatCount(d.followers_count ?? 0) },
      { label: 'Following', value: formatCount(d.follows_count ?? 0) },
      { label: 'Posts', value: formatCount(d.media_count ?? 0) },
    ],
  }
}

function transformTikTok(d: TikTokProfileData): TransformedProfile {
  return {
    displayName: d.display_name ?? d.open_id,
    subtitle: d.profile_deep_link ?? '—',
    fields: [
      { label: 'Bio', value: d.bio_description ?? '—' },
    ],
    stats: [
      { label: 'Followers', value: formatCount(d.follower_count ?? 0) },
      { label: 'Following', value: formatCount(d.following_count ?? 0) },
      { label: 'Likes', value: formatCount(d.likes_count ?? 0) },
      { label: 'Videos', value: formatCount(d.video_count ?? 0) },
    ],
  }
}

function transformGitLab(d: GitLabProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.username,
    subtitle: `@${d.username ?? ''}`,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Bio', value: d.bio ?? '—' },
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Website', value: d.website_url ?? '—', mono: true },
    ],
    stats: [
      { label: 'Repos', value: formatCount(d.public_repos ?? 0) },
      { label: 'Followers', value: formatCount(d.followers ?? 0) },
      { label: 'Following', value: formatCount(d.following ?? 0) },
    ],
  }
}

function transformStackOverflow(d: StackOverflowProfileData): TransformedProfile {
  const { bronze = 0, silver = 0, gold = 0 } = d.badge_counts ?? {}
  return {
    displayName: d.display_name ?? `User ${d.user_id}`,
    subtitle: d.link ?? `stackoverflow.com/users/${d.user_id}`,
    fields: [
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Employee', value: d.is_employee ? 'Yes (Staff)' : 'Community' },
      { label: 'Badges', value: `🥇${gold} 🥈${silver} 🥉${bronze}` },
    ],
    stats: [
      { label: 'Reputation', value: formatCount(d.reputation ?? 0) },
      { label: 'Questions', value: formatCount(d.question_count ?? 0) },
      { label: 'Answers', value: formatCount(d.answer_count ?? 0) },
    ],
  }
}

function transformUpwork(d: UpworkProfileData): TransformedProfile {
  return {
    displayName: d.name ?? '—',
    subtitle: d.title ?? '—',
    fields: [
      { label: 'Rate', value: d.hourly_rate ? `$${d.hourly_rate}/hr` : '—' },
      { label: 'Bio', value: d.description ?? '—' },
      { label: 'Skills', value: (d.skills ?? []).slice(0, 4).join(', ') || '—' },
    ],
    stats: [
      { label: 'Jobs', value: formatCount(d.total_jobs ?? 0) },
      { label: 'Hours', value: formatCount(d.total_hours ?? 0) },
      { label: 'Score', value: d.feedback_score ? d.feedback_score.toFixed(1) : '—' },
    ],
  }
}

function transformFiverr(d: FiverrProfileData): TransformedProfile {
  return {
    displayName: d.display_name ?? d.username,
    subtitle: `fiverr.com/${d.username ?? ''}`,
    fields: [
      { label: 'Level', value: d.seller_level ?? '—' },
      { label: 'Bio', value: d.description ?? '—' },
      { label: 'Member Since', value: d.member_since ?? '—' },
    ],
    stats: [
      { label: 'Gigs', value: formatCount(d.gig_count ?? 0) },
      { label: 'Rating', value: d.rating ? `${d.rating.toFixed(1)} ★` : '—' },
      { label: 'Reviews', value: formatCount(d.rating_count ?? 0) },
    ],
  }
}

function transformSoundCloud(d: SoundCloudProfileData): TransformedProfile {
  return {
    displayName: d.full_name || d.username,
    subtitle: d.permalink_url ?? `soundcloud.com/${d.username}`,
    fields: [
      { label: 'Bio', value: d.description ?? '—' },
      { label: 'City', value: d.city ?? '—' },
      { label: 'Country', value: d.country_code ?? '—' },
    ],
    stats: [
      { label: 'Followers', value: formatCount(d.followers_count ?? 0) },
      { label: 'Tracks', value: formatCount(d.track_count ?? 0) },
      { label: 'Likes', value: formatCount(d.public_likes_count ?? 0) },
    ],
  }
}

function transformBandcamp(d: BandcampProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.subdomain,
    subtitle: d.url ?? `${d.subdomain}.bandcamp.com`,
    fields: [
      { label: 'Bio', value: d.bio ?? '—' },
      { label: 'Location', value: d.location ?? '—' },
      { label: 'Website', value: d.website ?? '—', mono: true },
    ],
    stats: [{ label: 'Followers', value: formatCount(d.followers ?? 0) }],
  }
}

function transformBehance(d: BehanceProfileData): TransformedProfile {
  return {
    displayName: d.display_name ?? d.username,
    subtitle: d.url ?? `behance.net/${d.username}`,
    fields: [
      { label: 'Occupation', value: d.occupation ?? '—' },
      { label: 'Location', value: `${d.city ?? ''}${d.country ? `, ${d.country}` : ''}` || '—' },
      { label: 'Fields', value: (d.fields ?? []).join(', ') || '—' },
    ],
    stats: [
      { label: 'Followers', value: formatCount(d.stats?.followers ?? 0) },
      { label: 'Views', value: formatCount(d.stats?.views ?? 0) },
      { label: 'Appreciated', value: formatCount(d.stats?.appreciations ?? 0) },
    ],
  }
}

function transformStripe(d: StripeProfileData): TransformedProfile {
  return {
    displayName: d.business_profile?.name ?? d.id,
    subtitle: d.business_profile?.url ?? d.id,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Country', value: d.country ?? '—' },
      { label: 'Currency', value: (d.default_currency ?? '').toUpperCase() },
      { label: 'Charges', value: d.charges_enabled ? 'Enabled ✓' : 'Disabled' },
      { label: 'Payouts', value: d.payouts_enabled ? 'Enabled ✓' : 'Disabled' },
    ],
    stats: [],
  }
}

function transformPayPal(d: PayPalProfileData): TransformedProfile {
  return {
    displayName: d.name ?? `${d.given_name ?? ''} ${d.family_name ?? ''}`.trim(),
    subtitle: d.email ?? '—',
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Account', value: d.account_type ?? '—' },
      { label: 'Verified', value: d.verified_account ? 'Yes ✓' : 'No' },
    ],
    stats: [],
  }
}

function transformShopify(d: ShopifyProfileData): TransformedProfile {
  return {
    displayName: d.name ?? d.myshopify_domain,
    subtitle: d.domain ?? d.myshopify_domain,
    fields: [
      { label: 'Email', value: d.email ?? '—', sensitive: true },
      { label: 'Owner', value: d.shop_owner ?? '—' },
      { label: 'Plan', value: d.plan_display_name ?? d.plan_name ?? '—' },
      { label: 'Currency', value: d.currency ?? '—' },
      { label: 'Country', value: d.country_code ?? '—' },
    ],
    stats: d.product_count !== undefined
      ? [{ label: 'Products', value: formatCount(d.product_count) }]
      : [],
  }
}

// ─── Dispatcher ───────────────────────────────────────────────────────────────

/**
 * Dispatch to the correct transformer by platform ID.
 * Uses optional chaining on the raw data cast to be safe against partial shapes.
 * Returns null for unknown platform IDs.
 */
export function transformProfile(id: string, data: unknown): TransformedProfile | null {
  if (!data) return null
  try {
    switch (id) {
      case 'github':       return transformGitHub(data as GitHubProfileData)
      case 'google':       return transformGoogle(data as GoogleProfileData)
      case 'linkedin':     return transformLinkedIn(data as LinkedInProfileData)
      case 'twitter':      return transformTwitter(data as TwitterProfileData)
      case 'discord':      return transformDiscord(data as DiscordProfileData)
      case 'spotify':      return transformSpotify(data as SpotifyProfileData)
      case 'youtube':      return transformYouTube(data as YouTubeProfileData)
      case 'twitch':       return transformTwitch(data as TwitchProfileData)
      case 'instagram':    return transformInstagram(data as InstagramProfileData)
      case 'tiktok':       return transformTikTok(data as TikTokProfileData)
      case 'gitlab':       return transformGitLab(data as GitLabProfileData)
      case 'stackoverflow':return transformStackOverflow(data as StackOverflowProfileData)
      case 'upwork':       return transformUpwork(data as UpworkProfileData)
      case 'fiverr':       return transformFiverr(data as FiverrProfileData)
      case 'soundcloud':   return transformSoundCloud(data as SoundCloudProfileData)
      case 'bandcamp':     return transformBandcamp(data as BandcampProfileData)
      case 'behance':      return transformBehance(data as BehanceProfileData)
      case 'stripe':       return transformStripe(data as StripeProfileData)
      case 'paypal':       return transformPayPal(data as PayPalProfileData)
      case 'shopify':      return transformShopify(data as ShopifyProfileData)
      default:             return null
    }
  } catch {
    return null
  }
}
