/**
 * localStorage persistence for user-defined custom platforms and saved sets.
 * All keys are prefixed with `dih_` to avoid collisions.
 */

import type { PlatformConfig, PlatformCategory } from './platformConfig'

// ─── Storage keys ─────────────────────────────────────────────────────────────

export const CUSTOM_PLATFORMS_KEY = 'dih_customPlatforms'
export const CUSTOM_SETS_KEY = 'dih_customSets'

// ─── Types ────────────────────────────────────────────────────────────────────

export type CustomPlatformInput = {
  name: string
  apiBaseUrl: string
  category: PlatformCategory
}

export type CustomPersonaSet = {
  id: string
  name: string
  platformIds: string[]
  createdAt: number
}

// ─── Custom Platform builders ─────────────────────────────────────────────────

function genCustomId(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
  return `custom_${slug}_${Date.now()}`
}

/** Convert user input into a full PlatformConfig with sensible defaults. */
export function buildCustomPlatform(input: CustomPlatformInput): PlatformConfig {
  const base = input.apiBaseUrl.trim().replace(/\/$/, '')
  const name = input.name.trim()
  return {
    id: genCustomId(name),
    name,
    category: input.category,
    description: `Custom platform — ${base}`,
    logoInitials: name.slice(0, 2).toUpperCase(),
    logoHex: '#6366F1',
    logoTextHex: '#ffffff',
    settingsUrl: base,
    profileEditUrl: base,
    oauth: {
      authorizationUrl: `${base}/oauth/authorize`,
      accessTokenUrl: `${base}/oauth/token`,
      scopes: ['read'],
      docsUrl: base,
    },
    apiEndpoint: base,
    isCustom: true,
  }
}

// ─── Generic localStorage helpers ────────────────────────────────────────────

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw !== null ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* quota exceeded — ignore */
  }
}

// ─── Custom Platforms ─────────────────────────────────────────────────────────

export function loadCustomPlatforms(): PlatformConfig[] {
  return readJson<PlatformConfig[]>(CUSTOM_PLATFORMS_KEY, [])
}

export function saveCustomPlatforms(platforms: PlatformConfig[]): void {
  writeJson(CUSTOM_PLATFORMS_KEY, platforms)
}

// ─── Custom Sets ──────────────────────────────────────────────────────────────

export function loadCustomSets(): CustomPersonaSet[] {
  return readJson<CustomPersonaSet[]>(CUSTOM_SETS_KEY, [])
}

export function saveCustomSets(sets: CustomPersonaSet[]): void {
  writeJson(CUSTOM_SETS_KEY, sets)
}

export function createCustomSet(name: string, platformIds: string[]): CustomPersonaSet {
  return {
    id: `set_${Date.now()}`,
    name: name.trim(),
    platformIds: [...platformIds],
    createdAt: Date.now(),
  }
}
