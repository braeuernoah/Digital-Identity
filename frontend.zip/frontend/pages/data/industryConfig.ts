import type { IndustryId } from './platformRegistry'

// ─── Industry Type ────────────────────────────────────────────────────────────

export type Industry = {
  id: IndustryId
  name: string
  shortName: string
  description: string
  icon: string
  /** All default platform IDs for this industry */
  platformIds: string[]
  /** Tailwind accent color class (for badges, borders) */
  accentColor: string
  /** Tailwind bg gradient classes for the header chip */
  gradientFrom: string
  gradientTo: string
}

// ─── Registry ─────────────────────────────────────────────────────────────────

export const INDUSTRIES: Industry[] = [
  {
    id: 'creators',
    name: 'Creators & Marketers',
    shortName: 'Creators',
    description: 'Content creators, streamers, social media marketers and digital advertisers',
    icon: '🎬',
    platformIds: ['youtube', 'tiktok', 'instagram', 'twitch', 'meta_business', 'google_ads'],
    accentColor: 'text-red-500',
    gradientFrom: 'from-red-500/15',
    gradientTo: 'to-purple-500/15',
  },
  {
    id: 'musicians',
    name: 'Artists & Musicians',
    shortName: 'Musicians',
    description: 'Recording artists, producers, bands and audio creators distributing music',
    icon: '🎵',
    platformIds: ['spotify_artists', 'soundcloud', 'apple_music_artists', 'bandcamp'],
    accentColor: 'text-green-500',
    gradientFrom: 'from-green-500/15',
    gradientTo: 'to-emerald-500/15',
  },
  {
    id: 'freelancers',
    name: 'Freelancers & Entrepreneurs',
    shortName: 'Freelancers',
    description: 'Independent professionals, solopreneurs and remote-work service providers',
    icon: '💼',
    platformIds: ['upwork', 'fiverr', 'linkedin', 'stripe', 'paypal'],
    accentColor: 'text-blue-500',
    gradientFrom: 'from-blue-500/15',
    gradientTo: 'to-cyan-500/15',
  },
  {
    id: 'real_estate',
    name: 'Real Estate Agents',
    shortName: 'Real Estate',
    description: 'Property agents (Makler), brokers and realtors managing listings and profiles',
    icon: '🏡',
    platformIds: ['realtor', 'zillow', 'redfin', 'mls'],
    accentColor: 'text-orange-500',
    gradientFrom: 'from-orange-500/15',
    gradientTo: 'to-amber-500/15',
  },
  {
    id: 'ecommerce',
    name: 'E-Commerce',
    shortName: 'E-Commerce',
    description: 'Online store owners and marketplace sellers managing product catalogues',
    icon: '🛒',
    platformIds: ['shopify', 'amazon_seller', 'woocommerce', 'etsy'],
    accentColor: 'text-violet-500',
    gradientFrom: 'from-violet-500/15',
    gradientTo: 'to-indigo-500/15',
  },
  {
    id: 'entertainment',
    name: 'Celebrities & Entertainment',
    shortName: 'Entertainment',
    description: 'Actors, athletes, public figures and entertainment professionals',
    icon: '⭐',
    platformIds: ['imdb', 'wikipedia', 'cameo', 'linktree'],
    accentColor: 'text-yellow-500',
    gradientFrom: 'from-yellow-500/15',
    gradientTo: 'to-amber-500/15',
  },
  {
    id: 'crm',
    name: 'CRM Platforms',
    shortName: 'CRM',
    description: 'Sales teams, account managers and operations using CRM workflows',
    icon: '📊',
    platformIds: ['salesforce', 'hubspot', 'zoho_crm', 'pipedrive'],
    accentColor: 'text-sky-500',
    gradientFrom: 'from-sky-500/15',
    gradientTo: 'to-blue-500/15',
  },
  {
    id: 'general',
    name: 'General & Miscellaneous',
    shortName: 'General',
    description: 'Everyday online services — accounts, messaging, cloud storage and productivity tools',
    icon: '🌐',
    platformIds: ['google_account', 'microsoft_account', 'reddit', 'pinterest', 'snapchat', 'telegram', 'whatsapp_business', 'notion', 'dropbox', 'zoom'],
    accentColor: 'text-slate-500',
    gradientFrom: 'from-slate-500/15',
    gradientTo: 'to-gray-500/15',
  },
  {
    id: 'monetization',
    name: 'Monetization & Digital Income',
    shortName: 'Monetization',
    description: 'Platforms where creators and users earn money, run side hustles and grow audiences into revenue',
    icon: '💰',
    platformIds: ['patreon', 'substack', 'gumroad', 'kofi', 'buymeacoffee', 'medium', 'kickstarter', 'ebay_seller', 'etsy_shop'],
    accentColor: 'text-emerald-500',
    gradientFrom: 'from-emerald-500/15',
    gradientTo: 'to-teal-500/15',
  },
]

export const INDUSTRIES_BY_ID: Record<IndustryId, Industry> = Object.fromEntries(
  INDUSTRIES.map(i => [i.id, i]),
) as Record<IndustryId, Industry>
