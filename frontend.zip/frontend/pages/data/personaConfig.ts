// ─── Persona Registry ─────────────────────────────────────────────────────────
// Each persona maps to a curated set of platform IDs that match the digital
// identity needs of that role. Platform IDs must match PLATFORMS_BY_ID keys.

export type PersonaId =
  | 'content_creator'
  | 'programmer'
  | 'freelancer'
  | 'musician_artist'
  | 'entrepreneur'

export type Persona = {
  id: PersonaId
  name: string
  description: string
  /** Single emoji used in persona selection UI */
  icon: string
  /** Ordered list of platform IDs active for this persona by default */
  platformIds: string[]
  /** Tailwind gradient for persona card */
  gradientFrom: string
  gradientTo: string
}

export const PERSONAS: Persona[] = [
  {
    id: 'content_creator',
    name: 'Content Creator',
    description: 'Videos, livestreams, and short-form social content',
    icon: '🎬',
    platformIds: ['youtube', 'twitch', 'instagram', 'tiktok'],
    gradientFrom: 'from-red-500/10',
    gradientTo: 'to-purple-500/10',
  },
  {
    id: 'programmer',
    name: 'Programmer',
    description: 'Code repositories, Q&A, and dev communities',
    icon: '💻',
    platformIds: ['github', 'gitlab', 'stackoverflow'],
    gradientFrom: 'from-gray-500/10',
    gradientTo: 'to-orange-500/10',
  },
  {
    id: 'freelancer',
    name: 'Freelancer',
    description: 'Gig platforms and professional networking',
    icon: '💼',
    platformIds: ['upwork', 'fiverr', 'linkedin'],
    gradientFrom: 'from-green-500/10',
    gradientTo: 'to-blue-500/10',
  },
  {
    id: 'musician_artist',
    name: 'Musician / Artist',
    description: 'Music streaming, audio sharing, and creative portfolios',
    icon: '🎨',
    platformIds: ['spotify', 'soundcloud', 'bandcamp', 'behance'],
    gradientFrom: 'from-green-500/10',
    gradientTo: 'to-cyan-500/10',
  },
  {
    id: 'entrepreneur',
    name: 'Entrepreneur',
    description: 'Payments, e-commerce, and social brand presence',
    icon: '🚀',
    platformIds: ['stripe', 'paypal', 'twitter', 'shopify'],
    gradientFrom: 'from-indigo-500/10',
    gradientTo: 'to-yellow-500/10',
  },
]

export const PERSONAS_BY_ID: Record<PersonaId, Persona> = Object.fromEntries(
  PERSONAS.map(p => [p.id, p]),
) as Record<PersonaId, Persona>

/** Return the persona whose platform set has the most overlap with the given active IDs */
export function inferPersona(activeIds: string[]): PersonaId | null {
  if (activeIds.length === 0) return null
  const activeSet = new Set(activeIds)
  let best: PersonaId | null = null
  let bestCount = 0
  for (const p of PERSONAS) {
    const count = p.platformIds.filter(id => activeSet.has(id)).length
    if (count > bestCount) { bestCount = count; best = p.id }
  }
  return best
}
