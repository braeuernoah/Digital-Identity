// ─── Shared Types ─────────────────────────────────────────────────────────────

export type PlatformStatus = 'idle' | 'loading' | 'connected' | 'error' | 'disconnected'

export type PlatformCategory =
  | 'social'
  | 'developer'
  | 'identity'
  | 'entertainment'
  | 'creator'
  | 'creative'
  | 'freelance'
  | 'business'

export type ProfileField = {
  label: string
  value: string
  mono?: boolean
  sensitive?: boolean
}

export type StatItem = {
  label: string
  value: string
}

export type TransformedProfile = {
  displayName: string
  subtitle: string
  fields: ProfileField[]
  stats: StatItem[]
}

export type OAuthConfig = {
  authorizationUrl: string
  accessTokenUrl: string
  scopes: string[]
  docsUrl: string
}

export type PlatformConfig = {
  id: string
  name: string
  category: PlatformCategory
  description: string
  logoInitials: string
  /** CSS hex for logo badge background */
  logoHex: string
  /** CSS hex for logo badge text */
  logoTextHex: string
  /** Official account/settings page */
  settingsUrl: string
  /** Direct profile editing page */
  profileEditUrl: string
  oauth: OAuthConfig
  apiEndpoint: string
  /** True for user-created custom platforms */
  isCustom?: boolean
}

// ─── Platform Registry ────────────────────────────────────────────────────────

export const PLATFORMS: PlatformConfig[] = [
  // ── Identity ───────────────────────────────────────────────────────────────
  {
    id: 'google',
    name: 'Google',
    category: 'identity',
    description: 'Google Account & Gmail identity',
    logoInitials: 'G',
    logoHex: '#4285F4',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://myaccount.google.com/',
    profileEditUrl: 'https://myaccount.google.com/personal-info',
    oauth: {
      authorizationUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
      accessTokenUrl: 'https://oauth2.googleapis.com/token',
      scopes: ['openid', 'email', 'profile'],
      docsUrl: 'https://developers.google.com/identity/protocols/oauth2',
    },
    apiEndpoint: 'https://openidconnect.googleapis.com/v1/userinfo',
  },

  // ── Developer ──────────────────────────────────────────────────────────────
  {
    id: 'github',
    name: 'GitHub',
    category: 'developer',
    description: 'Code hosting & open-source collaboration',
    logoInitials: 'GH',
    logoHex: '#24292f',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://github.com/settings/account',
    profileEditUrl: 'https://github.com/settings/profile',
    oauth: {
      authorizationUrl: 'https://github.com/login/oauth/authorize',
      accessTokenUrl: 'https://github.com/login/oauth/access_token',
      scopes: ['read:user', 'user:email'],
      docsUrl: 'https://docs.github.com/en/apps/oauth-apps/building-oauth-apps',
    },
    apiEndpoint: 'https://api.github.com/user',
  },
  {
    id: 'gitlab',
    name: 'GitLab',
    category: 'developer',
    description: 'DevOps platform & private repositories',
    logoInitials: 'GL',
    logoHex: '#FC6D26',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://gitlab.com/-/profile',
    profileEditUrl: 'https://gitlab.com/-/profile',
    oauth: {
      authorizationUrl: 'https://gitlab.com/oauth/authorize',
      accessTokenUrl: 'https://gitlab.com/oauth/token',
      scopes: ['read_user'],
      docsUrl: 'https://docs.gitlab.com/ee/api/oauth2.html',
    },
    apiEndpoint: 'https://gitlab.com/api/v4/user',
  },
  {
    id: 'stackoverflow',
    name: 'Stack Overflow',
    category: 'developer',
    description: 'Q&A reputation & developer knowledge',
    logoInitials: 'SO',
    logoHex: '#F48024',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://stackoverflow.com/users/edit/current',
    profileEditUrl: 'https://stackoverflow.com/users/edit/current',
    oauth: {
      authorizationUrl: 'https://stackoverflow.com/oauth',
      accessTokenUrl: 'https://stackoverflow.com/oauth/access_token/json',
      scopes: ['no_expiry'],
      docsUrl: 'https://api.stackexchange.com/docs/authentication',
    },
    apiEndpoint: 'https://api.stackexchange.com/2.3/me?site=stackoverflow',
  },

  // ── Social ─────────────────────────────────────────────────────────────────
  {
    id: 'linkedin',
    name: 'LinkedIn',
    category: 'social',
    description: 'Professional network & career identity',
    logoInitials: 'in',
    logoHex: '#0A66C2',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.linkedin.com/settings/v2/',
    profileEditUrl: 'https://www.linkedin.com/in/me/',
    oauth: {
      authorizationUrl: 'https://www.linkedin.com/oauth/v2/authorization',
      accessTokenUrl: 'https://www.linkedin.com/oauth/v2/accessToken',
      scopes: ['r_liteprofile', 'r_emailaddress'],
      docsUrl: 'https://docs.microsoft.com/en-us/linkedin/shared/authentication/authorization-code-flow',
    },
    apiEndpoint: 'https://api.linkedin.com/v2/me',
  },
  {
    id: 'twitter',
    name: 'X / Twitter',
    category: 'social',
    description: 'Real-time social media & public conversation',
    logoInitials: 'X',
    logoHex: '#000000',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://twitter.com/settings/account',
    profileEditUrl: 'https://twitter.com/settings/profile',
    oauth: {
      authorizationUrl: 'https://twitter.com/i/oauth2/authorize',
      accessTokenUrl: 'https://api.twitter.com/2/oauth2/token',
      scopes: ['tweet.read', 'users.read', 'offline.access'],
      docsUrl: 'https://developer.twitter.com/en/docs/authentication/oauth-2-0',
    },
    apiEndpoint: 'https://api.twitter.com/2/users/me',
  },
  {
    id: 'discord',
    name: 'Discord',
    category: 'social',
    description: 'Community chat & developer social platform',
    logoInitials: 'DC',
    logoHex: '#5865F2',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://discord.com/settings/account',
    profileEditUrl: 'https://discord.com/settings/profile-customization',
    oauth: {
      authorizationUrl: 'https://discord.com/api/oauth2/authorize',
      accessTokenUrl: 'https://discord.com/api/oauth2/token',
      scopes: ['identify', 'email'],
      docsUrl: 'https://discord.com/developers/docs/topics/oauth2',
    },
    apiEndpoint: 'https://discord.com/api/v10/users/@me',
  },

  // ── Content Creator ────────────────────────────────────────────────────────
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'creator',
    description: 'Video publishing & channel analytics',
    logoInitials: 'YT',
    logoHex: '#FF0000',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://studio.youtube.com/',
    profileEditUrl: 'https://studio.youtube.com/channel/edit/basicinfo',
    oauth: {
      authorizationUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
      accessTokenUrl: 'https://oauth2.googleapis.com/token',
      scopes: ['https://www.googleapis.com/auth/youtube.readonly'],
      docsUrl: 'https://developers.google.com/youtube/v3/getting-started',
    },
    apiEndpoint: 'https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true',
  },
  {
    id: 'twitch',
    name: 'Twitch',
    category: 'creator',
    description: 'Live streaming & gaming community',
    logoInitials: 'TV',
    logoHex: '#9146FF',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.twitch.tv/settings/profile',
    profileEditUrl: 'https://www.twitch.tv/settings/profile',
    oauth: {
      authorizationUrl: 'https://id.twitch.tv/oauth2/authorize',
      accessTokenUrl: 'https://id.twitch.tv/oauth2/token',
      scopes: ['user:read:email'],
      docsUrl: 'https://dev.twitch.tv/docs/authentication',
    },
    apiEndpoint: 'https://api.twitch.tv/helix/users',
  },
  {
    id: 'instagram',
    name: 'Instagram',
    category: 'creator',
    description: 'Photo & video social media platform',
    logoInitials: 'IG',
    logoHex: '#E1306C',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.instagram.com/accounts/edit/',
    profileEditUrl: 'https://www.instagram.com/accounts/edit/',
    oauth: {
      authorizationUrl: 'https://api.instagram.com/oauth/authorize',
      accessTokenUrl: 'https://api.instagram.com/oauth/access_token',
      scopes: ['user_profile', 'user_media'],
      docsUrl: 'https://developers.facebook.com/docs/instagram-basic-display-api',
    },
    apiEndpoint: 'https://graph.instagram.com/me?fields=id,username,name,biography,followers_count',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    category: 'creator',
    description: 'Short-form video & creator economy',
    logoInitials: 'TK',
    logoHex: '#010101',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.tiktok.com/settings/',
    profileEditUrl: 'https://www.tiktok.com/setting/',
    oauth: {
      authorizationUrl: 'https://www.tiktok.com/v2/auth/authorize/',
      accessTokenUrl: 'https://open.tiktokapis.com/v2/oauth/token/',
      scopes: ['user.info.basic', 'user.info.profile', 'user.info.stats'],
      docsUrl: 'https://developers.tiktok.com/doc/login-kit-web',
    },
    apiEndpoint: 'https://open.tiktokapis.com/v2/user/info/',
  },

  // ── Entertainment ──────────────────────────────────────────────────────────
  {
    id: 'spotify',
    name: 'Spotify',
    category: 'entertainment',
    description: 'Music streaming & audio identity',
    logoInitials: 'SP',
    logoHex: '#1DB954',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.spotify.com/account/overview/',
    profileEditUrl: 'https://www.spotify.com/account/profile/',
    oauth: {
      authorizationUrl: 'https://accounts.spotify.com/authorize',
      accessTokenUrl: 'https://accounts.spotify.com/api/token',
      scopes: ['user-read-email', 'user-read-private'],
      docsUrl: 'https://developer.spotify.com/documentation/web-api/tutorials/getting-started',
    },
    apiEndpoint: 'https://api.spotify.com/v1/me',
  },

  // ── Creative ───────────────────────────────────────────────────────────────
  {
    id: 'soundcloud',
    name: 'SoundCloud',
    category: 'creative',
    description: 'Audio sharing & independent music',
    logoInitials: 'SC',
    logoHex: '#FF5500',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://soundcloud.com/settings',
    profileEditUrl: 'https://soundcloud.com/settings/profile',
    oauth: {
      authorizationUrl: 'https://soundcloud.com/connect',
      accessTokenUrl: 'https://api.soundcloud.com/oauth2/token',
      scopes: ['non-expiring'],
      docsUrl: 'https://developers.soundcloud.com/docs/api/guide',
    },
    apiEndpoint: 'https://api.soundcloud.com/me',
  },
  {
    id: 'bandcamp',
    name: 'Bandcamp',
    category: 'creative',
    description: 'Independent artist music & merch sales',
    logoInitials: 'BC',
    logoHex: '#1DA0C3',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://bandcamp.com/settings',
    profileEditUrl: 'https://bandcamp.com/settings',
    oauth: {
      authorizationUrl: 'https://bandcamp.com/oauth_login',
      accessTokenUrl: 'https://bandcamp.com/oauth_token',
      scopes: ['fan_read'],
      docsUrl: 'https://bandcamp.com/developer',
    },
    apiEndpoint: 'https://bandcamp.com/api/fan/2/info',
  },
  {
    id: 'behance',
    name: 'Behance',
    category: 'creative',
    description: 'Creative portfolio & design showcase',
    logoInitials: 'Be',
    logoHex: '#1769FF',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.behance.net/settings',
    profileEditUrl: 'https://www.behance.net/settings/profile',
    oauth: {
      authorizationUrl: 'https://www.behance.net/v2/oauth/authenticate',
      accessTokenUrl: 'https://www.behance.net/v2/oauth/token',
      scopes: ['activity_read'],
      docsUrl: 'https://www.behance.net/dev/api/endpoints/',
    },
    apiEndpoint: 'https://api.behance.net/v2/users/me',
  },

  // ── Freelance ──────────────────────────────────────────────────────────────
  {
    id: 'upwork',
    name: 'Upwork',
    category: 'freelance',
    description: 'Freelance contracts & client marketplace',
    logoInitials: 'UW',
    logoHex: '#14A800',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.upwork.com/freelancers/settings/contactInfo',
    profileEditUrl: 'https://www.upwork.com/freelancers/settings/profileVisibility',
    oauth: {
      authorizationUrl: 'https://www.upwork.com/ab/account-security/oauth2/authorize',
      accessTokenUrl: 'https://www.upwork.com/api/v3/oauth2/token',
      scopes: ['read_general', 'read_contract'],
      docsUrl: 'https://developers.upwork.com/?lang=node#authentication_how-to-authorize-user',
    },
    apiEndpoint: 'https://www.upwork.com/api/profiles/v1/me/profile',
  },
  {
    id: 'fiverr',
    name: 'Fiverr',
    category: 'freelance',
    description: 'Gig marketplace & freelance services',
    logoInitials: 'FV',
    logoHex: '#1DBF73',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.fiverr.com/users/settings',
    profileEditUrl: 'https://www.fiverr.com/users/edit',
    oauth: {
      authorizationUrl: 'https://www.fiverr.com/oauth2/authorize',
      accessTokenUrl: 'https://api.fiverr.com/oauth2/token',
      scopes: ['profile', 'gig_management'],
      docsUrl: 'https://developers.fiverr.com/',
    },
    apiEndpoint: 'https://api.fiverr.com/v1/me',
  },

  // ── Business ───────────────────────────────────────────────────────────────
  {
    id: 'stripe',
    name: 'Stripe',
    category: 'business',
    description: 'Payment processing & revenue analytics',
    logoInitials: 'ST',
    logoHex: '#635BFF',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://dashboard.stripe.com/settings',
    profileEditUrl: 'https://dashboard.stripe.com/settings/account',
    oauth: {
      authorizationUrl: 'https://connect.stripe.com/oauth/authorize',
      accessTokenUrl: 'https://connect.stripe.com/oauth/token',
      scopes: ['read_only'],
      docsUrl: 'https://stripe.com/docs/connect/oauth-reference',
    },
    apiEndpoint: 'https://api.stripe.com/v1/account',
  },
  {
    id: 'paypal',
    name: 'PayPal',
    category: 'business',
    description: 'Digital payments & commerce identity',
    logoInitials: 'PP',
    logoHex: '#003087',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://www.paypal.com/myaccount/settings/',
    profileEditUrl: 'https://www.paypal.com/myaccount/profile/',
    oauth: {
      authorizationUrl: 'https://www.paypal.com/signin/authorize',
      accessTokenUrl: 'https://api-m.paypal.com/v1/oauth2/token',
      scopes: ['openid', 'profile', 'email'],
      docsUrl: 'https://developer.paypal.com/api/rest/authentication/',
    },
    apiEndpoint: 'https://api-m.paypal.com/v1/identity/openidconnect/userinfo',
  },
  {
    id: 'shopify',
    name: 'Shopify',
    category: 'business',
    description: 'E-commerce store & sales management',
    logoInitials: 'SH',
    logoHex: '#96BF48',
    logoTextHex: '#ffffff',
    settingsUrl: 'https://admin.shopify.com/store/settings',
    profileEditUrl: 'https://admin.shopify.com/store/settings/general',
    oauth: {
      authorizationUrl: 'https://{shop}.myshopify.com/admin/oauth/authorize',
      accessTokenUrl: 'https://{shop}.myshopify.com/admin/oauth/access_token',
      scopes: ['read_orders', 'read_products', 'read_customers'],
      docsUrl: 'https://shopify.dev/docs/apps/auth/oauth',
    },
    apiEndpoint: 'https://{shop}.myshopify.com/admin/api/2024-01/shop.json',
  },
]

// ─── Lookup helpers ────────────────────────────────────────────────────────────

export const PLATFORMS_BY_ID: Record<string, PlatformConfig> = Object.fromEntries(
  PLATFORMS.map(p => [p.id, p]),
)

export function findPlatform(id: string): PlatformConfig | undefined {
  return PLATFORMS_BY_ID[id]
}

export const CATEGORY_LABELS: Record<PlatformCategory, string> = {
  social: 'Social',
  developer: 'Developer',
  identity: 'Identity',
  entertainment: 'Entertainment',
  creator: 'Creator',
  creative: 'Creative',
  freelance: 'Freelance',
  business: 'Business',
}

/** Build an OAuth 2.0 authorization URL (requires real client_id in production) */
export function buildOAuthUrl(config: PlatformConfig, clientId = 'YOUR_CLIENT_ID'): string {
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'code',
    scope: config.oauth.scopes.join(' '),
    redirect_uri: `${window.location.origin}/oauth/callback/${config.id}`,
    state: btoa(JSON.stringify({ platform: config.id, ts: Date.now() })),
  })
  return `${config.oauth.authorizationUrl}?${params.toString()}`
}

/** Format large numbers (1847 → "1.8K") */
export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}
