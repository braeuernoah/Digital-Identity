// Profile data types that mirror each backend function's return shape.
// Kept in the frontend layer so Dashboard imports don't pull in backend-only globals.

// ─── Existing platforms ────────────────────────────────────────────────────────

export type GitHubProfileData = {
  login: string; name: string; email: string | null; bio: string | null
  location: string | null; company: string | null; avatar_url: string
  html_url: string; followers: number; following: number
  public_repos: number; created_at: string
}

export type GoogleProfileData = {
  sub: string; name: string; given_name: string; family_name: string
  email: string; email_verified: boolean; picture: string; locale: string; hd?: string
}

export type LinkedInProfileData = {
  id: string; localizedFirstName: string; localizedLastName: string
  localizedHeadline: string; email: string; vanityName: string
  location: string; industry: string; summary: string
}

export type TwitterProfileData = {
  id: string; name: string; username: string; description: string
  location: string; profile_image_url: string
  public_metrics: { followers_count: number; following_count: number; tweet_count: number }
  verified: boolean; created_at: string
}

export type DiscordProfileData = {
  id: string; username: string; global_name: string | null; discriminator: string
  email: string; verified: boolean; bio: string; avatar: string | null
  banner: string | null; premium_type: number; locale: string
}

export type SpotifyProfileData = {
  id: string; display_name: string; email: string; country: string; product: string
  followers: { total: number }
  images: { url: string; height: number | null; width: number | null }[]
  external_urls: { spotify: string }
  explicit_content: { filter_enabled: boolean; filter_locked: boolean }
}

// ─── Content Creator platforms ─────────────────────────────────────────────────

export type YouTubeProfileData = {
  id: string
  snippet: {
    title: string; description: string; customUrl: string
    publishedAt: string; country: string
    thumbnails: { default: { url: string } }
  }
  statistics: {
    viewCount: string; subscriberCount: string
    hiddenSubscriberCount: boolean; videoCount: string
  }
}

export type TwitchProfileData = {
  id: string; login: string; display_name: string; email: string
  profile_image_url: string; view_count: number
  created_at: string; description: string; broadcaster_type: string
}

export type InstagramProfileData = {
  id: string; username: string; name: string; biography: string
  followers_count: number; follows_count: number; media_count: number
  profile_picture_url: string; website: string; account_type: string
}

export type TikTokProfileData = {
  open_id: string; union_id: string; avatar_url: string; display_name: string
  bio_description: string; profile_deep_link: string
  follower_count: number; following_count: number; likes_count: number; video_count: number
}

// ─── Developer platforms ───────────────────────────────────────────────────────

export type GitLabProfileData = {
  id: number; username: string; name: string; email: string; bio: string | null
  location: string | null; website_url: string; avatar_url: string
  created_at: string; public_repos: number; followers: number; following: number
}

export type StackOverflowProfileData = {
  user_id: number; display_name: string; reputation: number
  badge_counts: { bronze: number; silver: number; gold: number }
  location: string; profile_image: string; link: string; is_employee: boolean
  question_count: number; answer_count: number
}

// ─── Freelancer platforms ──────────────────────────────────────────────────────

export type UpworkProfileData = {
  id: string; profile_url: string; name: string; title: string; description: string
  skills: string[]; hourly_rate: string; total_jobs: number; total_hours: number
  feedback_score: number; feedback_count: number; member_since: string
}

export type FiverrProfileData = {
  username: string; display_name: string; description: string; seller_level: string
  rating: number; rating_count: number; member_since: string; profile_url: string
  gig_count: number; response_rate: number
}

// ─── Creative / Musician platforms ────────────────────────────────────────────

export type SoundCloudProfileData = {
  id: number; username: string; full_name: string; description: string | null
  city: string | null; country_code: string | null; followers_count: number
  followings_count: number; public_likes_count: number; track_count: number; permalink_url: string
}

export type BandcampProfileData = {
  id: number; name: string; subdomain: string; url: string; image_url: string
  bio: string; location: string; website: string; followers: number
}

export type BehanceProfileData = {
  id: number; username: string; display_name: string; occupation: string
  city: string; country: string; fields: string[]
  stats: { followers: number; following: number; appreciations: number; views: number; comments: number }
  url: string
}

// ─── Entrepreneur / Business platforms ────────────────────────────────────────

export type StripeProfileData = {
  id: string; object: string
  business_profile: { name: string | null; url: string | null; support_email: string | null }
  email: string; country: string; default_currency: string; created: number
  charges_enabled: boolean; payouts_enabled: boolean; details_submitted: boolean
}

export type PayPalProfileData = {
  user_id: string; sub: string; email: string; name: string
  given_name: string; family_name: string; verified: boolean
  account_type: string; verified_account: boolean; email_verified: boolean
}

export type ShopifyProfileData = {
  id: number; name: string; email: string; domain: string; myshopify_domain: string
  plan_name: string; plan_display_name: string; shop_owner: string
  currency: string; country_code: string; created_at: string; product_count?: number
}

/** Generic wrapper for all platform backend responses */
export type PlatformResponse<T> =
  | { data: T; error: null }
  | { data: null; error: { code: string; message: string } }
