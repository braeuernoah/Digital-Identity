import { useState } from 'react'
import {
  Map, CheckCircle, Circle, Sparkles, Code2, Rocket,
  GitBranch, ChevronRight, Lock, Zap, LayoutDashboard,
} from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../lib/shadcn/dialog'
import { Badge } from '../../lib/shadcn/badge'
import { Separator } from '../../lib/shadcn/separator'

// ─── Milestone Types ──────────────────────────────────────────────────────────

type MilestoneStatus = 'done' | 'current' | 'upcoming'

type Milestone = {
  version: string
  title: string
  status: MilestoneStatus
  items: string[]
}

const MILESTONES: Milestone[] = [
  {
    version: 'v0.1 – v0.9',
    title: 'No-Code Foundations',
    status: 'done',
    items: [
      "Built entirely inside Retool's visual editor — zero hand-written code",
      'Established platform catalog concept with manual deep-link curation',
      'Proof-of-concept for centralised account maintenance in one place',
      'Validated industry-grouping model with early user testing',
    ],
  },
  {
    version: 'v1.0',
    title: 'First Custom-Coded Release',
    status: 'current',
    items: [
      'Migrated 100 % of UI to hand-written React + TypeScript inside Retool R2',
      'Expanded catalog: General & Miscellaneous + Monetization & Digital Income',
      'AI-powered platform search — discover any platform and add it instantly',
      'Persistent dashboard with industry preset loader & custom platform builder',
    ],
  },
  {
    version: 'v1.5',
    title: 'Enhanced Data Layer',
    status: 'upcoming',
    items: [
      'Persisted user dashboards via Retool DB — survive across sessions & devices',
      'OAuth token storage layer for automated account health checks',
      'Custom platform import / export (JSON backup)',
      'Category tagging & multi-filter search across all platforms',
    ],
  },
  {
    version: 'v2.0',
    title: 'Live OAuth 2.0 Connections',
    status: 'upcoming',
    items: [
      'Real OAuth 2.0 authentication flows for every major platform in the catalog',
      'Secure token storage — encrypted at rest, scoped per user account',
      'Native API reads: pull real-time profile data, follower counts, account health',
      'Automated profile-completeness scoring and stale-data notifications',
    ],
  },
  {
    version: 'v3.0',
    title: 'Standalone Self-Made Software',
    status: 'upcoming',
    items: [
      'Full extraction from Retool — standalone, 100 % self-programmed application',
      'Docker-compose self-hosting with PostgreSQL + Redis backend',
      'Multi-user accounts, role-based access, and shareable dashboards',
      'Community-contributed platform definitions via GitHub pull requests',
    ],
  },
]

// ─── Status helpers ───────────────────────────────────────────────────────────

function StatusIcon({ status }: { status: MilestoneStatus }) {
  if (status === 'done')
    return <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
  if (status === 'current')
    return <Sparkles className="h-5 w-5 text-yellow-500 dark:text-yellow-400 shrink-0 mt-0.5" />
  return <Circle className="h-5 w-5 text-muted-foreground/40 shrink-0 mt-0.5" />
}

function statusBadge(status: MilestoneStatus) {
  if (status === 'done')
    return <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Released</Badge>
  if (status === 'current')
    return (
      <Badge className="text-[10px] px-1.5 py-0 bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 border-yellow-500/30">
        Current
      </Badge>
    )
  return <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-muted-foreground">Planned</Badge>
}

// ─── Roadmap Modal ────────────────────────────────────────────────────────────

export function RoadmapModal() {
  const [open, setOpen] = useState(false)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 gap-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <Map className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Roadmap</span>
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader className="pb-2">
          <div className="flex items-center gap-2 mb-1">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Rocket className="h-4 w-4 text-primary" />
            </div>
            <DialogTitle className="text-base font-semibold">
              Project Vision & Roadmap
            </DialogTitle>
          </div>
        </DialogHeader>

        {/* ── Vision statement ── */}
        <div className="rounded-xl border bg-card p-4 space-y-3">
          <div className="flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              The Ultimate Goal
            </span>
          </div>
          <p className="text-sm text-foreground leading-relaxed">
            <strong>Retool Deep-Link Directory</strong> is a stepping stone — not the
            destination. The final vision is a{' '}
            <strong>completely self-programmed, custom-coded central dashboard</strong> built
            entirely from scratch, independent of any no-code or low-code platform.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Every line of code in this project is written by hand — this version inside
            Retool R2 represents the transition phase: moving from dragging components in a
            visual editor to shipping a production-grade, fully self-authored web application.
          </p>
        </div>

        {/* ── Three pillars of the final product ── */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-xl border bg-card p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-500/10">
                <Lock className="h-3.5 w-3.5 text-blue-500" />
              </div>
              <span className="text-xs font-semibold text-foreground">Real OAuth 2.0</span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              The final software will securely connect to every supported platform using
              real OAuth 2.0 authentication flows — tokens stored encrypted, scoped per user.
            </p>
          </div>

          <div className="rounded-xl border bg-card p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500/10">
                <Zap className="h-3.5 w-3.5 text-emerald-500" />
              </div>
              <span className="text-xs font-semibold text-foreground">Native API Reads</span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Leverage each platform's native API to read, filter and summarise
              real-time profile data, account health metrics and public statistics —
              all surfaced inside a single dashboard.
            </p>
          </div>

          <div className="rounded-xl border bg-card p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-500/10">
                <LayoutDashboard className="h-3.5 w-3.5 text-violet-500" />
              </div>
              <span className="text-xs font-semibold text-foreground">Deep-Link Core</span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              The direct deep-link redirection mechanism — the heart of this tool — will
              always be retained, giving users instant one-click access to every account's
              profile maintenance page.
            </p>
          </div>
        </div>

        <Separator className="my-1" />

        {/* ── Tech stack note ── */}
        <div className="flex items-start gap-2 rounded-lg bg-primary/5 border border-primary/15 px-3 py-2.5">
          <Code2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">Current stack:</span>{' '}
            React 18 · TypeScript 5 · Tailwind CSS · shadcn/ui · Vite · Retool R2 ·
            Anthropic AI —{' '}
            <span className="font-medium text-foreground">Target stack:</span>{' '}
            Next.js · PostgreSQL · Redis · Docker · custom OAuth server · REST + GraphQL APIs.
          </p>
        </div>

        {/* ── Milestone timeline ── */}
        <div className="space-y-3 pt-1">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Development Milestones
          </p>

          {MILESTONES.map((m, i) => (
            <div
              key={m.version}
              className={`relative rounded-xl border p-4 transition-colors ${
                m.status === 'current'
                  ? 'border-yellow-500/40 bg-yellow-500/5 dark:bg-yellow-500/[0.06]'
                  : m.status === 'done'
                  ? 'bg-card'
                  : 'bg-muted/30 border-dashed'
              }`}
            >
              {/* Connector line between milestones */}
              {i < MILESTONES.length - 1 && (
                <div className="absolute left-[1.9rem] top-full h-3 w-px bg-border" />
              )}

              <div className="flex items-start gap-3">
                <StatusIcon status={m.status} />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="text-xs font-mono text-muted-foreground">{m.version}</span>
                    <ChevronRight className="h-3 w-3 text-muted-foreground/50" />
                    <span className="text-sm font-semibold text-foreground">{m.title}</span>
                    {statusBadge(m.status)}
                  </div>
                  <ul className="space-y-1">
                    {m.items.map((item, j) => (
                      <li
                        key={j}
                        className="flex items-start gap-1.5 text-xs text-muted-foreground"
                      >
                        <span className="mt-1 h-1 w-1 rounded-full bg-muted-foreground/50 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Footer ── */}
        <div className="rounded-lg bg-muted/50 px-3 py-2.5 text-center">
          <p className="text-xs text-muted-foreground">
            Built with care by{' '}
            <span className="font-medium text-foreground">@noahbraeuer287</span>
            {' '}· This Retool version is a milestone on the journey to a fully
            self-made, open-source platform — one version at a time.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
