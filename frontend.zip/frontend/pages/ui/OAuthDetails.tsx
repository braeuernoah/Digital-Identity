import { useState, type ReactNode } from 'react'
import {
  ChevronDown, ChevronRight, ExternalLink,
  Copy, Check, BookOpen, Wrench,
} from 'lucide-react'
import type { OAuthConfig } from '../data/platformConfig'

type Props = {
  oauth: OAuthConfig
  platformName: string
  /** Platform ID used to derive the Retool resource name and backend file path */
  platformId?: string
  /** API base endpoint for Step 1 */
  apiEndpoint?: string
  /** Custom platforms show simplified guidance */
  isCustom?: boolean
}

export function OAuthDetails({ oauth, platformName, platformId, apiEndpoint, isCustom }: Props) {
  const [techOpen, setTechOpen] = useState(false)
  const [copiedKey, setCopiedKey] = useState<string | null>(null)

  // Derive the exact Retool resource name expected by the backend function
  const resourceName = platformId
    ? `${platformId.toLowerCase().replace(/[^a-z0-9]/g, '')}OAuth`
    : `${platformName.toLowerCase().replace(/[^a-z0-9]/g, '')}OAuth`

  // Derive the backend file path
  const fnName = platformId
    ? `${platformId.charAt(0).toUpperCase()}${platformId.slice(1)}`
    : platformName.replace(/[^a-zA-Z]/g, '')
  const backendFile = `get${fnName}Profile.ts`

  // Display the base URL (prefer apiEndpoint, fall back to auth URL origin)
  const baseUrl =
    apiEndpoint ??
    (() => {
      try {
        return new URL(oauth.authorizationUrl).origin
      } catch {
        return oauth.authorizationUrl
      }
    })()

  function copy(text: string, key: string) {
    navigator.clipboard.writeText(text).then(
      () => { setCopiedKey(key); setTimeout(() => setCopiedKey(null), 2000) },
      () => { /* permission denied */ },
    )
  }

  // ── Custom platform guidance ───────────────────────────────────────────────
  if (isCustom) {
    return (
      <div className="rounded-lg border border-border/70 bg-muted/20 overflow-hidden text-xs">
        <div className="px-3 py-2.5 bg-muted/30 border-b border-border/50 flex items-center gap-1.5 font-semibold text-foreground">
          <Wrench className="w-3.5 h-3.5 text-primary" />
          Connecting Custom Platform
        </div>
        <div className="px-3 py-3 space-y-3">
          <Step n={1} title="Create a Retool REST API Resource">
            <p className="text-muted-foreground leading-relaxed">
              Go to <strong className="text-foreground">Retool → Resources → + Create new → REST API</strong>.
              Set the Base URL to:{' '}
              <CopyChip value={baseUrl} copyKey="baseUrl" copiedKey={copiedKey} onCopy={copy} />
            </p>
          </Step>
          <Step n={2} title="Set up authentication">
            <p className="text-muted-foreground leading-relaxed">
              Configure the Authentication tab to match the target API's OAuth or API-key requirements.
              Once set up, write a backend function under{' '}
              <code className="bg-background border border-border px-1 py-0.5 rounded font-mono text-[10px] text-foreground">
                /backend/platforms/
              </code>{' '}
              that calls your new resource and returns a{' '}
              <code className="bg-background border border-border px-1 py-0.5 rounded font-mono text-[10px] text-foreground">
                {'{ data, error }'}
              </code>{' '}
              shaped response.
            </p>
          </Step>
          <Step n={3} title="Sync to see live data">
            <p className="text-muted-foreground leading-relaxed">
              Click <strong className="text-foreground">Sync All</strong> once your resource and backend function are ready.
            </p>
          </Step>
        </div>
      </div>
    )
  }

  // ── Standard platform guidance ────────────────────────────────────────────
  return (
    <div className="rounded-lg border border-border/70 bg-muted/20 overflow-hidden text-xs">
      {/* Header */}
      <div className="px-3 py-2.5 bg-muted/30 border-b border-border/50 flex items-center justify-between">
        <span className="flex items-center gap-1.5 font-semibold text-foreground">
          <BookOpen className="w-3.5 h-3.5 text-primary" />
          How to Connect {platformName}
        </span>
        <a
          href={oauth.docsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[10px] text-primary hover:underline"
        >
          OAuth Docs <ExternalLink className="w-2.5 h-2.5" />
        </a>
      </div>

      {/* Numbered steps */}
      <div className="px-3 py-3 space-y-3.5">
        <Step n={1} title="Create a Retool REST API Resource">
          <p className="text-muted-foreground leading-relaxed">
            Go to <strong className="text-foreground">Retool → Resources → + Create new → REST API</strong>.
            Set the Base URL to:{' '}
            <CopyChip value={baseUrl} copyKey="baseUrl" copiedKey={copiedKey} onCopy={copy} />
          </p>
        </Step>

        <Step n={2} title="Configure OAuth 2.0 Authentication">
          <div className="space-y-1.5 text-muted-foreground">
            <p>
              Set <strong className="text-foreground">Authentication type → OAuth 2.0</strong>, then fill in:
            </p>
            <div className="pl-1 space-y-1.5">
              <FieldRow
                label="Auth URL" value={oauth.authorizationUrl}
                copyKey="authUrl" copiedKey={copiedKey} onCopy={copy}
              />
              <FieldRow
                label="Token URL" value={oauth.accessTokenUrl}
                copyKey="tokenUrl" copiedKey={copiedKey} onCopy={copy}
              />
              <div className="flex gap-2 items-start">
                <span className="text-muted-foreground/70 w-16 flex-shrink-0">Scopes</span>
                <div className="flex flex-wrap gap-1">
                  {oauth.scopes.map(s => (
                    <span key={s} className="px-1.5 py-px bg-primary/10 text-primary rounded font-mono text-[10px]">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
              <p className="text-[10px] pt-0.5">
                Get your <strong className="text-foreground">Client ID</strong> and{' '}
                <strong className="text-foreground">Client Secret</strong> from the{' '}
                <a href={oauth.docsUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                  {platformName} developer console
                </a>
                .
              </p>
            </div>
          </div>
        </Step>

        <Step n={3} title="Name the resource exactly:">
          <div className="flex items-center gap-2 mt-1">
            <code className="flex-1 font-mono text-[11px] bg-background border border-border px-2 py-1.5 rounded text-foreground truncate">
              {resourceName}
            </code>
            <button
              onClick={() => copy(resourceName, 'resName')}
              className="p-1.5 rounded border border-border hover:bg-accent transition-colors text-muted-foreground hover:text-foreground flex-shrink-0"
              title="Copy resource name"
            >
              {copiedKey === 'resName'
                ? <Check className="w-3 h-3 text-primary" />
                : <Copy className="w-3 h-3" />}
            </button>
          </div>
          <p className="text-muted-foreground mt-1 leading-relaxed">
            The name must match exactly — the backend function references this resource by name.
          </p>
        </Step>

        <Step n={4} title="Enable the production API call">
          <p className="text-muted-foreground leading-relaxed">
            Open{' '}
            <code className="bg-background border border-border px-1 py-0.5 rounded font-mono text-[10px] text-foreground">
              /backend/platforms/{backendFile}
            </code>{' '}
            and replace the <code className="font-mono text-[10px]">NOT_CONNECTED</code> stub
            with the real API call shown in the comments at the top of that file.
            The 401/403 handlers for token expiry are already written — just uncomment them.
          </p>
        </Step>

        <Step n={5} title="Sync and verify">
          <p className="text-muted-foreground leading-relaxed">
            Click <strong className="text-foreground">Sync All</strong> in the dashboard header.
            This card will show your live {platformName} profile once the OAuth flow completes.
            If you see a <em>Session Expired</em> error later, click{' '}
            <strong className="text-foreground">Re-authenticate</strong> to refresh your token.
          </p>
        </Step>
      </div>

      {/* Technical details (collapsible) */}
      <div className="border-t border-border/50">
        <button
          onClick={() => setTechOpen(v => !v)}
          className="w-full flex items-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
        >
          {techOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          Technical Details
        </button>
        {techOpen && (
          <div className="px-3 pb-3 space-y-1.5 border-t border-border/30">
            <TechRow label="Auth URL" value={oauth.authorizationUrl} />
            <TechRow label="Token URL" value={oauth.accessTokenUrl} />
            <div className="flex gap-2 min-w-0 pt-1.5">
              <span className="text-[10px] font-medium text-muted-foreground w-16 flex-shrink-0 pt-px">Scopes</span>
              <div className="flex flex-wrap gap-1 flex-1">
                {oauth.scopes.map(s => (
                  <span key={s} className="px-1.5 py-px bg-primary/10 text-primary text-[10px] rounded font-mono">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Sub-components ────────────────────────────────────────────────────────────

function Step({ n, title, children }: { n: number; title: string; children: ReactNode }) {
  return (
    <div className="flex gap-2.5">
      <div className="w-5 h-5 rounded-full bg-primary/15 text-primary flex-shrink-0 flex items-center justify-center text-[10px] font-bold mt-0.5">
        {n}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground mb-1 text-xs">{title}</p>
        <div className="text-xs">{children}</div>
      </div>
    </div>
  )
}

function CopyChip({
  value, copyKey, copiedKey, onCopy,
}: {
  value: string; copyKey: string; copiedKey: string | null
  onCopy: (v: string, k: string) => void
}) {
  return (
    <span className="inline-flex items-center gap-1">
      <code className="font-mono text-[10px] bg-background border border-border px-1.5 py-0.5 rounded text-foreground max-w-[180px] truncate" title={value}>
        {value}
      </code>
      <button
        onClick={() => onCopy(value, copyKey)}
        className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
        title="Copy"
      >
        {copiedKey === copyKey
          ? <Check className="w-2.5 h-2.5 text-primary" />
          : <Copy className="w-2.5 h-2.5" />}
      </button>
    </span>
  )
}

function FieldRow({
  label, value, copyKey, copiedKey, onCopy,
}: {
  label: string; value: string; copyKey: string
  copiedKey: string | null; onCopy: (v: string, k: string) => void
}) {
  return (
    <div className="flex gap-2 items-center min-w-0">
      <span className="text-muted-foreground/70 w-16 flex-shrink-0">{label}</span>
      <code className="font-mono text-[10px] text-foreground/80 flex-1 min-w-0 truncate" title={value}>
        {value}
      </code>
      <button
        onClick={() => onCopy(value, copyKey)}
        className="p-0.5 rounded text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
        title={`Copy ${label}`}
      >
        {copiedKey === copyKey
          ? <Check className="w-2.5 h-2.5 text-primary" />
          : <Copy className="w-2.5 h-2.5" />}
      </button>
    </div>
  )
}

function TechRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2 min-w-0 pt-1.5">
      <span className="text-[10px] font-medium text-muted-foreground w-16 flex-shrink-0 pt-px">{label}</span>
      <span className="font-mono text-[10px] text-foreground/80 flex-1 min-w-0 truncate" title={value}>
        {value}
      </span>
    </div>
  )
}
