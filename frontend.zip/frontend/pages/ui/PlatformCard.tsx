import { ExternalLink, Settings, UserPen, Plus, Minus, Trash2 } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { cn } from '../../lib/shadcn/utils'
import type { Platform } from '../data/platformRegistry'
import { INDUSTRIES_BY_ID } from '../data/industryConfig'

// ─── Props ────────────────────────────────────────────────────────────────────

type Props = {
  platform: Platform
  /** Whether this platform is currently on the user's dashboard */
  isActive: boolean
  /** When true, shows Add/Remove toggle instead of just action buttons */
  showToggle?: boolean
  /** Called when user clicks "Add to Dashboard" */
  onAdd?: () => void
  /** Called when user clicks "Remove" */
  onRemove?: () => void
  /** Extra wrapper class */
  className?: string
}

// ─── Component ────────────────────────────────────────────────────────────────

export function PlatformCard({
  platform,
  isActive,
  showToggle = false,
  onAdd,
  onRemove,
  className,
}: Props) {
  const industry = INDUSTRIES_BY_ID[platform.industry]

  function openUrl(url: string) {
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  return (
    <div
      className={cn(
        'group relative flex flex-col gap-3 rounded-xl border bg-card p-4 transition-all hover:shadow-md hover:border-border/80',
        isActive && 'ring-1 ring-primary/20',
        className,
      )}
    >
      {/* ── Header ── */}
      <div className="flex items-start gap-3">
        {/* Logo badge */}
        <div
          className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl text-xs font-bold tracking-tight shadow-sm"
          style={{ backgroundColor: platform.logoBg, color: platform.logoFg }}
          aria-hidden="true"
        >
          {platform.logoInitials}
        </div>

        {/* Name + description */}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="truncate text-sm font-semibold text-foreground leading-tight">
              {platform.name}
              {platform.isCustom && (
                <span className="ml-1.5 text-[10px] font-normal text-muted-foreground">
                  custom
                </span>
              )}
            </h3>
          </div>
          <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground leading-snug">
            {platform.description}
          </p>
        </div>
      </div>

      {/* ── Industry badge ── */}
      {industry && (
        <div className="flex items-center gap-1.5">
          <span className="text-xs">{industry.icon}</span>
          <span className="text-xs text-muted-foreground">{industry.shortName}</span>
        </div>
      )}

      {/* ── Maintenance action buttons ── */}
      <div className="flex flex-col gap-1.5">
        <Button
          size="sm"
          variant="outline"
          className="h-8 w-full justify-start gap-1.5 text-xs"
          onClick={() => openUrl(platform.settingsUrl)}
        >
          <Settings className="h-3 w-3 shrink-0" />
          {platform.settingsLabel}
          <ExternalLink className="ml-auto h-2.5 w-2.5 shrink-0 opacity-50" />
        </Button>

        {platform.profileUrl && (
          <Button
            size="sm"
            variant="outline"
            className="h-8 w-full justify-start gap-1.5 text-xs"
            onClick={() => openUrl(platform.profileUrl!)}
          >
            <UserPen className="h-3 w-3 shrink-0" />
            {platform.profileLabel ?? 'Edit Profile'}
            <ExternalLink className="ml-auto h-2.5 w-2.5 shrink-0 opacity-50" />
          </Button>
        )}
      </div>

      {/* ── Dashboard toggle ── */}
      {showToggle && (
        <div className="border-t pt-2">
          {isActive ? (
            <Button
              size="sm"
              variant="ghost"
              className="h-7 w-full gap-1.5 text-xs text-muted-foreground hover:text-destructive"
              onClick={onRemove}
            >
              <Minus className="h-3 w-3" />
              Remove from Dashboard
            </Button>
          ) : (
            <Button
              size="sm"
              variant="ghost"
              className="h-7 w-full gap-1.5 text-xs text-muted-foreground hover:text-primary"
              onClick={onAdd}
            >
              <Plus className="h-3 w-3" />
              Add to Dashboard
            </Button>
          )}
        </div>
      )}

      {/* ── Remove button (compact, for dashboard view) ── */}
      {!showToggle && isActive && onRemove && (
        <button
          onClick={onRemove}
          className="absolute right-2.5 top-2.5 flex h-6 w-6 items-center justify-center rounded-md opacity-0 transition-opacity group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive"
          aria-label={`Remove ${platform.name} from dashboard`}
        >
          <Trash2 className="h-3 w-3" />
        </button>
      )}
    </div>
  )
}
