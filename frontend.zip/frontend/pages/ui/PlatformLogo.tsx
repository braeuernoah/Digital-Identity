type Size = 'sm' | 'md' | 'lg'

type Props = {
  initials: string
  hex: string
  textHex: string
  size?: Size
}

function resolveSize(size: Size): string {
  if (size === 'sm') return 'w-8 h-8 text-xs'
  if (size === 'lg') return 'w-12 h-12 text-base'
  return 'w-10 h-10 text-sm'
}

export function PlatformLogo({ initials, hex, textHex, size = 'md' }: Props) {
  return (
    <div
      className={`${resolveSize(size)} rounded-xl flex items-center justify-center font-bold tracking-tight flex-shrink-0 shadow-sm`}
      style={{ backgroundColor: hex, color: textHex }}
      aria-hidden="true"
    >
      {initials}
    </div>
  )
}
