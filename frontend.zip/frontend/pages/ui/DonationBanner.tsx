import { useState } from 'react'
import { X, Heart } from 'lucide-react'

const PAYPAL_URL = 'https://www.paypal.com/paypalme/noahbraeuer287'
const DISMISSED_KEY = 'donation_banner_dismissed_v1'

export function DonationBanner() {
  const [visible, setVisible] = useState(() => {
    try {
      return sessionStorage.getItem(DISMISSED_KEY) !== 'true'
    } catch {
      return true
    }
  })

  if (!visible) return null

  function dismiss() {
    try {
      sessionStorage.setItem(DISMISSED_KEY, 'true')
    } catch {
      // ignore
    }
    setVisible(false)
  }

  return (
    <div
      className="fixed bottom-0 inset-x-0 z-30 pointer-events-none"
      role="complementary"
      aria-label="Support the developer"
    >
      <div className="pointer-events-auto mx-auto max-w-7xl px-4 pb-3 sm:px-6">
        <div className="flex items-center gap-3 rounded-xl border border-border/60 bg-card/95 backdrop-blur-sm shadow-sm px-4 py-2.5">
          {/* Icon */}
          <div className="shrink-0 flex h-7 w-7 items-center justify-center rounded-full bg-primary/10">
            <Heart className="h-3.5 w-3.5 text-primary" />
          </div>

          {/* Text */}
          <p className="flex-1 text-xs text-muted-foreground min-w-0">
            <span className="hidden sm:inline">
              If this directory saves you time, consider supporting its development — every
              contribution helps keep the project growing.{' '}
            </span>
            <span className="sm:hidden">Enjoying the app? </span>
            <a
              href={PAYPAL_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground underline underline-offset-2 hover:text-primary transition-colors"
            >
              Support via PayPal
            </a>
            <span className="text-muted-foreground/60"> · takes 10 seconds</span>
          </p>

          {/* Dismiss */}
          <button
            onClick={dismiss}
            aria-label="Dismiss donation notice"
            className="shrink-0 flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  )
}
