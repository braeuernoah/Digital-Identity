import { useState, useRef, useEffect } from 'react'
import {
  Search, Sparkles, Plus, ExternalLink, Settings, UserPen,
  AlertCircle, Loader2, ArrowRight, Info, CheckCircle2,
} from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Input } from '../../lib/shadcn/input'
import { Label } from '../../lib/shadcn/label'
import { Badge } from '../../lib/shadcn/badge'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../../lib/shadcn/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../lib/shadcn/select'
import { Separator } from '../../lib/shadcn/separator'
import { cn } from '../../lib/shadcn/utils'
import { useSearchPlatform } from '../../hooks/backend/platforms'
import { INDUSTRIES } from '../data/industryConfig'
import { buildCustomPlatform } from '../data/directoryStore'
import type { Platform, IndustryId } from '../data/platformRegistry'
import type { PlatformSearchResult } from '../data/searchTypes'

// ─── Props ────────────────────────────────────────────────────────────────────

type Props = {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAdd: (platform: Platform) => void
}

// ─── Confidence badge ─────────────────────────────────────────────────────────

function ConfidenceBadge({ level }: { level: PlatformSearchResult['confidence'] }) {
  if (level === 'high')
    return (
      <Badge className="gap-1 text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20">
        <CheckCircle2 className="h-2.5 w-2.5" />
        High confidence
      </Badge>
    )
  if (level === 'medium')
    return (
      <Badge className="gap-1 text-[10px] px-1.5 py-0 bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20">
        <Info className="h-2.5 w-2.5" />
        Medium confidence
      </Badge>
    )
  return (
    <Badge className="gap-1 text-[10px] px-1.5 py-0 bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/20">
      <AlertCircle className="h-2.5 w-2.5" />
      Low confidence — verify URLs
    </Badge>
  )
}

// ─── Preview Card ─────────────────────────────────────────────────────────────

function ResultPreviewCard({ result }: { result: PlatformSearchResult }) {
  return (
    <div className="rounded-xl border bg-card p-4 space-y-3">
      {/* Header */}
      <div className="flex items-start gap-3">
        <div
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xs font-bold tracking-tight shadow-sm"
          style={{ backgroundColor: result.logoBg, color: result.logoFg }}
        >
          {result.logoInitials}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-sm font-semibold text-foreground">{result.name}</h3>
            <ConfidenceBadge level={result.confidence} />
          </div>
          <p className="mt-0.5 text-xs text-muted-foreground leading-snug line-clamp-2">
            {result.description}
          </p>
        </div>
      </div>

      {/* Deep links */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground mb-1">
          Deep-links that will be added
        </p>
        <div
          className="flex items-center gap-2 rounded-lg border bg-muted/40 px-3 py-1.5 text-xs"
        >
          <Settings className="h-3 w-3 text-muted-foreground shrink-0" />
          <span className="font-medium text-foreground mr-1">{result.settingsLabel}</span>
          <span className="text-muted-foreground truncate flex-1 font-mono text-[10px]">
            {result.settingsUrl}
          </span>
          <ExternalLink className="h-2.5 w-2.5 text-muted-foreground shrink-0" />
        </div>
        {result.profileUrl && (
          <div className="flex items-center gap-2 rounded-lg border bg-muted/40 px-3 py-1.5 text-xs">
            <UserPen className="h-3 w-3 text-muted-foreground shrink-0" />
            <span className="font-medium text-foreground mr-1">{result.profileLabel ?? 'Edit Profile'}</span>
            <span className="text-muted-foreground truncate flex-1 font-mono text-[10px]">
              {result.profileUrl}
            </span>
            <ExternalLink className="h-2.5 w-2.5 text-muted-foreground shrink-0" />
          </div>
        )}
      </div>

      {result.confidence !== 'high' && (
        <p className="text-[10px] text-muted-foreground leading-relaxed flex items-start gap-1">
          <Info className="h-3 w-3 shrink-0 mt-0.5 text-yellow-500" />
          AI-generated URLs — please verify they open the correct page before relying on them.
        </p>
      )}
    </div>
  )
}

// ─── Main Dialog ──────────────────────────────────────────────────────────────

export function PlatformSearchDialog({ open, onOpenChange, onAdd }: Props) {
  const [query, setQuery] = useState('')
  const [result, setResult] = useState<PlatformSearchResult | null>(null)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [industry, setIndustry] = useState<IndustryId | ''>('')
  const inputRef = useRef<HTMLInputElement>(null)

  const { trigger, loading } = useSearchPlatform()

  // Auto-focus input when dialog opens
  useEffect(() => {
    if (open) {
      setQuery('')
      setResult(null)
      setErrorMsg(null)
      setIndustry('')
      setTimeout(() => inputRef.current?.focus(), 80)
    }
  }, [open])

  async function handleSearch() {
    const q = query.trim()
    if (!q) return
    setResult(null)
    setErrorMsg(null)

    const response = await trigger({ query: q })
    if (!response) { setErrorMsg('No response from server.'); return }

    if (response.ok === false) {
      if (response.reason === 'unknown_platform') {
        setErrorMsg(`"${q}" wasn't recognised as a known platform. Try a more specific name or use Add Custom Platform instead.`)
      } else if (response.reason === 'empty_query') {
        setErrorMsg('Please enter a platform name.')
      } else {
        setErrorMsg('Something went wrong parsing the result. Try again.')
      }
      return
    }

    setResult(response.platform)
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') handleSearch()
  }

  function handleAdd() {
    if (!result || !industry) return

    const platform = buildCustomPlatform({
      name: result.name,
      industry: industry as IndustryId,
      settingsUrl: result.settingsUrl,
      description: result.description,
      logoInitials: result.logoInitials,
    })

    // Preserve the AI-resolved brand colors and profile URL
    const enriched: Platform = {
      ...platform,
      logoBg: result.logoBg,
      logoFg: result.logoFg,
      ...(result.profileUrl
        ? {
            profileUrl: result.profileUrl,
            profileLabel: result.profileLabel ?? 'Edit Profile',
          }
        : {}),
    }

    onAdd(enriched)
    onOpenChange(false)
  }

  const canAdd = result !== null && industry !== ''

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
            </div>
            Discover Any Platform
          </DialogTitle>
        </DialogHeader>

        {/* Search bar */}
        <div className="space-y-2">
          <Label htmlFor="ps-query" className="text-xs text-muted-foreground">
            Platform name
          </Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="ps-query"
                ref={inputRef}
                placeholder="e.g. Calendly, Duolingo, Strava…"
                className="pl-9 h-9 text-sm"
                value={query}
                onChange={e => {
                  setQuery(e.target.value)
                  if (result || errorMsg) { setResult(null); setErrorMsg(null) }
                }}
                onKeyDown={handleKeyDown}
                disabled={loading}
              />
            </div>
            <Button
              size="sm"
              className="h-9 gap-1.5 px-4 shrink-0"
              onClick={handleSearch}
              disabled={loading || !query.trim()}
            >
              {loading ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Looking up…
                </>
              ) : (
                <>
                  <ArrowRight className="h-3.5 w-3.5" />
                  Find
                </>
              )}
            </Button>
          </div>

          <p className="text-[11px] text-muted-foreground flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-primary/70" />
            AI looks up official account settings & profile URLs automatically.
          </p>
        </div>

        {/* Error state */}
        {errorMsg && (
          <div className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5">
            <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
            <p className="text-xs text-destructive leading-relaxed">{errorMsg}</p>
          </div>
        )}

        {/* Result preview */}
        {result && (
          <>
            <Separator />
            <div className="space-y-3">
              <p className="text-xs font-medium text-muted-foreground">Platform discovered</p>
              <ResultPreviewCard result={result} />

              {/* Industry selector */}
              <div className="space-y-1.5">
                <Label htmlFor="ps-industry" className="text-xs">
                  File under industry{' '}
                  <span className="text-destructive">*</span>
                </Label>
                <Select value={industry} onValueChange={v => setIndustry(v as IndustryId)}>
                  <SelectTrigger id="ps-industry" className="h-9 text-xs">
                    <SelectValue placeholder="Select an industry category…" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map(ind => (
                      <SelectItem key={ind.id} value={ind.id} className="text-xs">
                        <span className="mr-2">{ind.icon}</span>
                        {ind.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-[10px] text-muted-foreground">
                  Determines which Explore tab this platform appears under.
                </p>
              </div>

              {/* Add button */}
              <Button
                className={cn('w-full gap-2', !canAdd && 'opacity-50')}
                onClick={handleAdd}
                disabled={!canAdd}
              >
                <Plus className="h-4 w-4" />
                Add{result ? ` ${result.name}` : ' Platform'} to Dashboard
              </Button>
            </div>
          </>
        )}

        {/* Loading skeleton */}
        {loading && (
          <div className="space-y-3 animate-pulse">
            <Separator />
            <div className="rounded-xl border bg-muted/30 p-4 space-y-3">
              <div className="flex items-start gap-3">
                <div className="h-11 w-11 rounded-xl bg-muted" />
                <div className="flex-1 space-y-2 pt-1">
                  <div className="h-3 w-32 rounded bg-muted" />
                  <div className="h-2.5 w-48 rounded bg-muted" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-8 rounded-lg bg-muted" />
                <div className="h-8 rounded-lg bg-muted" />
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ─── Trigger Button (exported for use in header) ──────────────────────────────

export function PlatformSearchTrigger({
  onClick,
}: {
  onClick: () => void
}) {
  return (
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5 text-xs"
      onClick={onClick}
    >
      <Search className="h-3.5 w-3.5" />
      <span className="hidden sm:inline">Search Platforms</span>
    </Button>
  )
}
