import { useState } from 'react'
import { ShieldCheck, ChevronRight, Check } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { cn } from '../../lib/shadcn/utils'
import { PERSONAS, type PersonaId, type Persona } from '../data/personaConfig'
import { PLATFORMS_BY_ID } from '../data/platformConfig'

type Props = {
  onComplete: (personaId: PersonaId, platformIds: string[]) => void
}

export function OnboardingModal({ onComplete }: Props) {
  const [selected, setSelected] = useState<PersonaId | null>(null)
  const hoveredPersona = selected ? PERSONAS.find(p => p.id === selected) ?? null : null

  function handleStart() {
    if (!selected) return
    const persona = PERSONAS.find(p => p.id === selected)
    if (!persona) return
    onComplete(selected, persona.platformIds)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-card border border-border rounded-2xl shadow-xl overflow-hidden">

        {/* Header */}
        <div className="px-6 pt-8 pb-6 text-center border-b border-border">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-foreground">Welcome to Digital Identity Hub</h1>
          <p className="text-sm text-muted-foreground mt-1.5 max-w-sm mx-auto">
            Who are you? Select a persona to load your default platform set — you can always customize it later.
          </p>
        </div>

        {/* Persona grid */}
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {PERSONAS.map(persona => (
            <PersonaCard
              key={persona.id}
              persona={persona}
              isSelected={selected === persona.id}
              onSelect={() => setSelected(persona.id)}
            />
          ))}
        </div>

        {/* Preview of selected platforms */}
        {hoveredPersona && (
          <div className="px-6 pb-2">
            <p className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wide">
              Platforms for {hoveredPersona.name}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {hoveredPersona.platformIds.map(id => {
                const cfg = PLATFORMS_BY_ID[id]
                if (!cfg) return null
                return (
                  <span
                    key={id}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border border-border bg-muted text-foreground"
                  >
                    <span
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: cfg.logoHex }}
                    />
                    {cfg.name}
                  </span>
                )
              })}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-5 border-t border-border flex items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            You can add or remove platforms at any time via the Manage Platforms panel.
          </p>
          <Button
            onClick={handleStart}
            disabled={!selected}
            className="flex-shrink-0 gap-1.5"
          >
            Get Started
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// ─── Persona Card ─────────────────────────────────────────────────────────────

function PersonaCard({
  persona,
  isSelected,
  onSelect,
}: {
  persona: Persona
  isSelected: boolean
  onSelect: () => void
}) {
  return (
    <button
      onClick={onSelect}
      className={cn(
        'relative flex items-start gap-3.5 p-4 rounded-xl border text-left transition-all duration-150',
        'hover:border-primary/50 hover:bg-accent',
        isSelected
          ? 'border-primary bg-primary/5 ring-1 ring-primary/30'
          : 'border-border bg-background',
      )}
    >
      {/* Check indicator */}
      {isSelected && (
        <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
          <Check className="w-3 h-3 text-primary-foreground" />
        </span>
      )}

      {/* Icon */}
      <span className="text-2xl leading-none mt-0.5 flex-shrink-0">{persona.icon}</span>

      {/* Text */}
      <div className="min-w-0">
        <p className="text-sm font-semibold text-foreground leading-snug">{persona.name}</p>
        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{persona.description}</p>
        <p className="text-[10px] text-muted-foreground/70 mt-1.5">
          {persona.platformIds.length} platforms
        </p>
      </div>
    </button>
  )
}
