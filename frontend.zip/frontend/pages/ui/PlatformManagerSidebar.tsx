import { useState, useMemo, useEffect } from 'react'
import {
  X, Plus, Trash2, Search, ChevronDown, ChevronRight,
  Save, Layers, Check, Pencil,
} from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Separator } from '../../lib/shadcn/separator'
import { cn } from '../../lib/shadcn/utils'
import { PLATFORMS, PLATFORMS_BY_ID, CATEGORY_LABELS, type PlatformConfig, type PlatformCategory } from '../data/platformConfig'
import { PERSONAS, type PersonaId } from '../data/personaConfig'
import type { CustomPersonaSet, CustomPlatformInput } from '../data/customStore'

type Props = {
  open: boolean
  activePlatformIds: string[]
  selectedPersona: PersonaId | null
  customPlatforms: PlatformConfig[]
  customSets: CustomPersonaSet[]
  onClose: () => void
  onAddPlatform: (id: string) => void
  onRemovePlatform: (id: string) => void
  onLoadPersona: (personaId: PersonaId) => void
  onAddCustomPlatform: (input: CustomPlatformInput) => void
  onSaveCustomSet: (name: string) => void
  onLoadCustomSet: (set: CustomPersonaSet) => void
  onDeleteCustomSet: (id: string) => void
}

type Tab = 'active' | 'add' | 'sets'

export function PlatformManagerSidebar({
  open,
  activePlatformIds,
  selectedPersona,
  customPlatforms,
  customSets,
  onClose,
  onAddPlatform,
  onRemovePlatform,
  onLoadPersona,
  onAddCustomPlatform,
  onSaveCustomSet,
  onLoadCustomSet,
  onDeleteCustomSet,
}: Props) {
  const [activeTab, setActiveTab] = useState<Tab>('active')
  const [search, setSearch] = useState('')

  // ── Bug fix #1: reset tab + search every time sidebar opens ───────────────
  useEffect(() => {
    if (open) {
      setActiveTab('active')
      setSearch('')
    }
  }, [open])

  const activeSet = new Set(activePlatformIds)

  // All available platforms (standard + user-created custom)
  const allPlatformsList = useMemo(
    () => [...PLATFORMS, ...customPlatforms],
    [customPlatforms],
  )

  // Platforms not yet in the active set, filtered by search
  const filteredPlatforms = useMemo(() => {
    const q = search.toLowerCase()
    return allPlatformsList.filter(
      p =>
        !activeSet.has(p.id) &&
        (p.name.toLowerCase().includes(q) || p.category.includes(q)),
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, activePlatformIds, allPlatformsList])

  return (
    <>
      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/30 backdrop-blur-[1px]"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Drawer */}
      <aside
        className={cn(
          'fixed top-0 right-0 z-50 h-full w-80 bg-card border-l border-border shadow-xl',
          'flex flex-col transition-transform duration-300 ease-in-out',
          open ? 'translate-x-0' : 'translate-x-full',
        )}
        aria-label="Platform Manager"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-border flex-shrink-0">
          <div>
            <h2 className="text-sm font-semibold text-foreground">Manage Platforms</h2>
            <p className="text-xs text-muted-foreground">{activePlatformIds.length} active</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close sidebar"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border flex-shrink-0">
          {([ 'active', 'add', 'sets'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                'flex-1 py-2.5 text-xs font-medium capitalize transition-colors',
                activeTab === tab
                  ? 'text-primary border-b-2 border-primary'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {tab === 'active'
                ? `Active (${activePlatformIds.length})`
                : tab === 'add'
                ? 'Add'
                : 'Sets'}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'active' && (
            <ActiveTab
              activePlatformIds={activePlatformIds}
              allPlatformsList={allPlatformsList}
              onRemove={onRemovePlatform}
              onSaveSet={onSaveCustomSet}
            />
          )}
          {activeTab === 'add' && (
            <AddTab
              search={search}
              onSearchChange={setSearch}
              filteredPlatforms={filteredPlatforms}
              onAdd={id => { onAddPlatform(id); setSearch('') }}
              onAddCustomPlatform={onAddCustomPlatform}
            />
          )}
          {activeTab === 'sets' && (
            <SetsTab
              activePlatformIds={activePlatformIds}
              selectedPersona={selectedPersona}
              customSets={customSets}
              onTogglePlatform={(id, isActive) =>
                isActive ? onRemovePlatform(id) : onAddPlatform(id)
              }
              onLoadPersona={id => { onLoadPersona(id); onClose() }}
              onLoadCustomSet={s => { onLoadCustomSet(s); onClose() }}
              onDeleteCustomSet={onDeleteCustomSet}
            />
          )}
        </div>
      </aside>
    </>
  )
}

// ─── Active Tab ───────────────────────────────────────────────────────────────

function ActiveTab({
  activePlatformIds,
  allPlatformsList,
  onRemove,
  onSaveSet,
}: {
  activePlatformIds: string[]
  allPlatformsList: PlatformConfig[]
  onRemove: (id: string) => void
  onSaveSet: (name: string) => void
}) {
  const [saveOpen, setSaveOpen] = useState(false)
  const [setName, setSetName] = useState('')

  const byId = useMemo(
    () => Object.fromEntries(allPlatformsList.map(p => [p.id, p])),
    [allPlatformsList],
  )

  function handleSave() {
    if (!setName.trim()) return
    onSaveSet(setName)
    setSetName('')
    setSaveOpen(false)
  }

  return (
    <div className="p-3 space-y-1 flex flex-col h-full">
      {activePlatformIds.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-10">
          No platforms active. Use the Add tab to add some.
        </p>
      ) : (
        activePlatformIds.map(id => {
          const cfg = byId[id]
          if (!cfg) return null
          return (
            <ActivePlatformRow key={id} config={cfg} onRemove={() => onRemove(id)} />
          )
        })
      )}

      {/* Save current set */}
      {activePlatformIds.length > 0 && (
        <div className="pt-3 mt-auto">
          <Separator className="mb-3" />
          {saveOpen ? (
            <div className="space-y-2">
              <p className="text-xs font-medium text-foreground">Save current set as…</p>
              <input
                autoFocus
                value={setName}
                onChange={e => setSetName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSave(); if (e.key === 'Escape') setSaveOpen(false) }}
                placeholder="Set name…"
                className="w-full px-2.5 py-1.5 text-xs bg-background border border-border rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <div className="flex gap-1.5">
                <Button size="sm" className="flex-1 h-7 text-xs gap-1" onClick={handleSave} disabled={!setName.trim()}>
                  <Save className="w-3 h-3" /> Save Set
                </Button>
                <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => { setSaveOpen(false); setSetName('') }}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setSaveOpen(true)}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-foreground border border-dashed border-border hover:border-primary/40 rounded-lg transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              Save current set
            </button>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Add Tab ──────────────────────────────────────────────────────────────────

function AddTab({
  search,
  onSearchChange,
  filteredPlatforms,
  onAdd,
  onAddCustomPlatform,
}: {
  search: string
  onSearchChange: (v: string) => void
  filteredPlatforms: PlatformConfig[]
  onAdd: (id: string) => void
  onAddCustomPlatform: (input: CustomPlatformInput) => void
}) {
  const [customOpen, setCustomOpen] = useState(false)
  const [customName, setCustomName] = useState('')
  const [customUrl, setCustomUrl] = useState('')
  const [customCategory, setCustomCategory] = useState<PlatformCategory>('social')
  const [urlError, setUrlError] = useState('')

  function validateUrl(v: string): boolean {
    try { new URL(v); return true } catch { return false }
  }

  function handleCreate() {
    if (!customName.trim()) return
    if (!validateUrl(customUrl.trim())) { setUrlError('Enter a valid URL (https://…)'); return }
    setUrlError('')
    onAddCustomPlatform({ name: customName, apiBaseUrl: customUrl, category: customCategory })
    setCustomName('')
    setCustomUrl('')
    setCustomCategory('social')
    setCustomOpen(false)
  }

  return (
    <div className="p-3 space-y-2 flex flex-col">
      {/* Search */}
      <div className="relative flex-shrink-0">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
        <input
          value={search}
          onChange={e => onSearchChange(e.target.value)}
          placeholder="Search platforms…"
          className="w-full pl-8 pr-3 py-2 text-xs bg-background border border-border rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      {/* Platform list */}
      {filteredPlatforms.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-6">
          {search ? 'No platforms match your search.' : 'All available platforms are already active.'}
        </p>
      ) : (
        <div className="space-y-1">
          {filteredPlatforms.map(cfg => (
            <AddPlatformRow key={cfg.id} config={cfg} onAdd={() => onAdd(cfg.id)} />
          ))}
        </div>
      )}

      {/* Create custom platform */}
      <div className="pt-2 mt-2">
        <Separator className="mb-3" />
        <button
          onClick={() => setCustomOpen(v => !v)}
          className="w-full flex items-center justify-between px-2 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          <span className="flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-primary" />
            Create Custom Platform
          </span>
          {customOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        </button>

        {customOpen && (
          <div className="mt-2 space-y-2 p-3 rounded-lg border border-border/70 bg-muted/20">
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Add any platform by entering its name and API base URL. You can then connect it by
              creating a matching Retool REST API resource.
            </p>
            <div className="space-y-2">
              <div>
                <label className="text-[10px] font-medium text-muted-foreground block mb-1">
                  Platform Name <span className="text-destructive">*</span>
                </label>
                <input
                  value={customName}
                  onChange={e => setCustomName(e.target.value)}
                  placeholder="e.g. My API, Notion, Linear…"
                  className="w-full px-2.5 py-1.5 text-xs bg-background border border-border rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted-foreground block mb-1">
                  API Base URL <span className="text-destructive">*</span>
                </label>
                <input
                  value={customUrl}
                  onChange={e => { setCustomUrl(e.target.value); setUrlError('') }}
                  placeholder="https://api.example.com"
                  className={cn(
                    'w-full px-2.5 py-1.5 text-xs bg-background border rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary',
                    urlError ? 'border-destructive' : 'border-border',
                  )}
                />
                {urlError && <p className="text-[10px] text-destructive mt-1">{urlError}</p>}
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted-foreground block mb-1">
                  Category
                </label>
                <select
                  value={customCategory}
                  onChange={e => setCustomCategory(e.target.value as PlatformCategory)}
                  className="w-full px-2.5 py-1.5 text-xs bg-background border border-border rounded-md text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  {(Object.entries(CATEGORY_LABELS) as [PlatformCategory, string][]).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>
              <Button
                size="sm"
                className="w-full h-7 text-xs gap-1"
                onClick={handleCreate}
                disabled={!customName.trim() || !customUrl.trim()}
              >
                <Plus className="w-3 h-3" />
                Add Custom Platform
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Sets Tab ─────────────────────────────────────────────────────────────────

function SetsTab({
  activePlatformIds,
  selectedPersona,
  customSets,
  onTogglePlatform,
  onLoadPersona,
  onLoadCustomSet,
  onDeleteCustomSet,
}: {
  activePlatformIds: string[]
  selectedPersona: PersonaId | null
  customSets: CustomPersonaSet[]
  onTogglePlatform: (id: string, isActive: boolean) => void
  onLoadPersona: (id: PersonaId) => void
  onLoadCustomSet: (set: CustomPersonaSet) => void
  onDeleteCustomSet: (id: string) => void
}) {
  const [expandedPersona, setExpandedPersona] = useState<PersonaId | null>(null)
  const activeSet = new Set(activePlatformIds)

  return (
    <div className="p-3 space-y-2">
      {/* Standard persona sets */}
      <p className="text-[10px] text-muted-foreground px-1 font-medium uppercase tracking-wide">
        Standard Personas
      </p>

      {PERSONAS.map(persona => {
        const isExpanded = expandedPersona === persona.id
        return (
          <div
            key={persona.id}
            className={cn(
              'rounded-lg border bg-background overflow-hidden transition-colors',
              selectedPersona === persona.id ? 'border-primary/40' : 'border-border',
            )}
          >
            {/* Persona header */}
            <button
              onClick={() => setExpandedPersona(isExpanded ? null : persona.id)}
              className="w-full flex items-center gap-3 p-3 text-left hover:bg-accent/50 transition-colors"
            >
              <span className="text-xl leading-none flex-shrink-0">{persona.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-semibold text-foreground">{persona.name}</p>
                  {selectedPersona === persona.id && (
                    <span className="text-[10px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground truncate">{persona.description}</p>
              </div>
              {isExpanded
                ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />}
            </button>

            {/* Expanded: per-platform toggles */}
            {isExpanded && (
              <div className="px-3 pb-3 pt-1 space-y-3 border-t border-border/50">
                <p className="text-[10px] text-muted-foreground">
                  Click a platform chip to add or remove it from your active set.
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {persona.platformIds.map(id => {
                    const cfg = PLATFORMS_BY_ID[id]
                    if (!cfg) return null
                    const isActive = activeSet.has(id)
                    return (
                      <button
                        key={id}
                        onClick={() => onTogglePlatform(id, isActive)}
                        title={isActive ? `Remove ${cfg.name}` : `Add ${cfg.name}`}
                        className={cn(
                          'inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-medium border transition-all',
                          isActive
                            ? 'bg-primary/10 border-primary/30 text-primary hover:bg-destructive/10 hover:border-destructive/30 hover:text-destructive'
                            : 'bg-muted border-border text-muted-foreground hover:bg-primary/10 hover:border-primary/30 hover:text-primary',
                        )}
                      >
                        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: cfg.logoHex }} />
                        {cfg.name}
                        {isActive
                          ? <X className="w-2.5 h-2.5" />
                          : <Plus className="w-2.5 h-2.5" />}
                      </button>
                    )
                  })}
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full h-7 text-xs gap-1"
                  onClick={() => onLoadPersona(persona.id)}
                >
                  <Layers className="w-3 h-3" />
                  Replace active set with {persona.name}
                </Button>
              </div>
            )}
          </div>
        )
      })}

      {/* Custom saved sets */}
      <Separator className="my-2" />
      <div className="flex items-center justify-between px-1">
        <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">
          Custom Sets
        </p>
        <span className="text-[10px] text-muted-foreground">
          {customSets.length} saved
        </span>
      </div>

      {customSets.length === 0 ? (
        <div className="px-1 py-4 text-center space-y-1">
          <Layers className="w-6 h-6 text-muted-foreground/40 mx-auto" />
          <p className="text-[10px] text-muted-foreground">
            No custom sets yet. Go to the <strong className="text-foreground">Active</strong> tab and
            click <strong className="text-foreground">Save current set</strong>.
          </p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {customSets.map(set => (
            <CustomSetCard
              key={set.id}
              set={set}
              onLoad={() => onLoadCustomSet(set)}
              onDelete={() => onDeleteCustomSet(set.id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Row / Card sub-components ────────────────────────────────────────────────

function ActivePlatformRow({ config, onRemove }: { config: PlatformConfig; onRemove: () => void }) {
  return (
    <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-accent/50 group">
      <span
        className="w-6 h-6 rounded-md flex-shrink-0 flex items-center justify-center text-[9px] font-bold"
        style={{ backgroundColor: config.logoHex, color: config.logoTextHex }}
      >
        {config.logoInitials.slice(0, 2)}
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-foreground leading-tight">
          {config.name}
          {config.isCustom && (
            <span className="ml-1 text-[10px] text-muted-foreground font-normal">(custom)</span>
          )}
        </p>
        <p className="text-[10px] text-muted-foreground capitalize">{config.category}</p>
      </div>
      <button
        onClick={onRemove}
        aria-label={`Remove ${config.name}`}
        className="p-1 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all"
      >
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  )
}

function AddPlatformRow({ config, onAdd }: { config: PlatformConfig; onAdd: () => void }) {
  return (
    <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-accent/50 group">
      <span
        className="w-6 h-6 rounded-md flex-shrink-0 flex items-center justify-center text-[9px] font-bold"
        style={{ backgroundColor: config.logoHex, color: config.logoTextHex }}
      >
        {config.logoInitials.slice(0, 2)}
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-foreground leading-tight">
          {config.name}
          {config.isCustom && (
            <span className="ml-1 text-[10px] text-muted-foreground font-normal">(custom)</span>
          )}
        </p>
        <p className="text-[10px] text-muted-foreground capitalize">{config.category}</p>
      </div>
      <button
        onClick={onAdd}
        aria-label={`Add ${config.name}`}
        className="p-1 rounded text-muted-foreground hover:text-primary hover:bg-primary/10 opacity-0 group-hover:opacity-100 transition-all"
      >
        <Plus className="w-3.5 h-3.5" />
      </button>
    </div>
  )
}

function CustomSetCard({
  set,
  onLoad,
  onDelete,
}: {
  set: CustomPersonaSet
  onLoad: () => void
  onDelete: () => void
}) {
  const [confirmDelete, setConfirmDelete] = useState(false)

  return (
    <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg border border-border bg-background hover:border-primary/30 transition-colors group">
      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-foreground truncate">{set.name}</p>
        <p className="text-[10px] text-muted-foreground">
          {set.platformIds.length} platforms · saved {new Date(set.createdAt).toLocaleDateString()}
        </p>
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        {confirmDelete ? (
          <>
            <button
              onClick={onDelete}
              className="p-1 rounded text-xs text-destructive hover:bg-destructive/10 transition-colors"
              title="Confirm delete"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setConfirmDelete(false)}
              className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              title="Cancel"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </>
        ) : (
          <>
            <button
              onClick={onLoad}
              className="p-1 rounded text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors opacity-0 group-hover:opacity-100"
              title="Load this set"
            >
              <Pencil className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setConfirmDelete(true)}
              className="p-1 rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors opacity-0 group-hover:opacity-100"
              title="Delete this set"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <Button
              size="sm"
              variant="outline"
              className="h-6 px-2 text-[10px]"
              onClick={onLoad}
            >
              Load
            </Button>
          </>
        )}
      </div>
    </div>
  )
}
