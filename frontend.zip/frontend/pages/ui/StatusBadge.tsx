import { PlatformStatus } from '../data/platformConfig'

type Props = {
  status: PlatformStatus
}

export function StatusBadge({ status }: Props) {
  if (status === 'connected') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-success/15 text-success border border-success/25">
        <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
        Connected
      </span>
    )
  }
  if (status === 'error') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-destructive/10 text-destructive border border-destructive/25">
        <span className="w-1.5 h-1.5 rounded-full bg-destructive" />
        Auth Error
      </span>
    )
  }
  if (status === 'disconnected') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground border border-border">
        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50" />
        Not Connected
      </span>
    )
  }
  if (status === 'loading') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-warning border border-warning/25">
        <span className="w-1.5 h-1.5 rounded-full bg-warning animate-ping" />
        Syncing
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground border border-border">
      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/30" />
      Idle
    </span>
  )
}
