import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../../lib/shadcn/dialog'
import { Input } from '../../lib/shadcn/input'
import { Label } from '../../lib/shadcn/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../lib/shadcn/select'
import { INDUSTRIES } from '../data/industryConfig'
import { buildCustomPlatform, type CustomPlatformInput } from '../data/directoryStore'
import type { Platform } from '../data/platformRegistry'
import type { IndustryId } from '../data/platformRegistry'

// ─── Props ────────────────────────────────────────────────────────────────────

type Props = {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAdd: (platform: Platform) => void
}

// ─── Blank form state ─────────────────────────────────────────────────────────

type FormState = {
  name: string
  industry: IndustryId | ''
  settingsUrl: string
  description: string
  logoInitials: string
}

const BLANK: FormState = {
  name: '',
  industry: '',
  settingsUrl: '',
  description: '',
  logoInitials: '',
}

// ─── Component ────────────────────────────────────────────────────────────────

export function AddCustomPlatformDialog({ open, onOpenChange, onAdd }: Props) {
  const [form, setForm] = useState<FormState>(BLANK)
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({})

  function setField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm(prev => ({ ...prev, [key]: value }))
    if (errors[key]) setErrors(prev => ({ ...prev, [key]: undefined }))
  }

  function validate(): boolean {
    const next: Partial<Record<keyof FormState, string>> = {}
    if (!form.name.trim()) next.name = 'Platform name is required'
    if (!form.industry) next.industry = 'Please select an industry'
    if (!form.settingsUrl.trim()) {
      next.settingsUrl = 'Settings URL is required'
    } else {
      try {
        new URL(form.settingsUrl.trim())
      } catch {
        next.settingsUrl = 'Must be a valid URL (include https://)'
      }
    }
    setErrors(next)
    return Object.keys(next).length === 0
  }

  function handleSubmit() {
    if (!validate()) return
    if (!form.industry) return

    const input: CustomPlatformInput = {
      name: form.name,
      industry: form.industry as IndustryId,
      settingsUrl: form.settingsUrl,
      ...(form.description.trim() ? { description: form.description } : {}),
      ...(form.logoInitials.trim() ? { logoInitials: form.logoInitials } : {}),
    }

    const platform = buildCustomPlatform(input)
    onAdd(platform)
    setForm(BLANK)
    setErrors({})
    onOpenChange(false)
  }

  function handleCancel() {
    setForm(BLANK)
    setErrors({})
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Custom Platform
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          {/* Name */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cp-name">Platform Name *</Label>
            <Input
              id="cp-name"
              placeholder="e.g. My Portfolio, Notion, Calendly"
              value={form.name}
              onChange={e => setField('name', e.target.value)}
            />
            {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
          </div>

          {/* Industry */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cp-industry">Industry *</Label>
            <Select
              value={form.industry}
              onValueChange={v => setField('industry', v as IndustryId)}
            >
              <SelectTrigger id="cp-industry">
                <SelectValue placeholder="Select an industry…" />
              </SelectTrigger>
              <SelectContent>
                {INDUSTRIES.map(ind => (
                  <SelectItem key={ind.id} value={ind.id}>
                    <span className="mr-2">{ind.icon}</span>
                    {ind.shortName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.industry && <p className="text-xs text-destructive">{errors.industry}</p>}
          </div>

          {/* Settings URL */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cp-url">Settings / Maintenance URL *</Label>
            <Input
              id="cp-url"
              type="url"
              placeholder="https://example.com/settings"
              value={form.settingsUrl}
              onChange={e => setField('settingsUrl', e.target.value)}
            />
            {errors.settingsUrl && (
              <p className="text-xs text-destructive">{errors.settingsUrl}</p>
            )}
          </div>

          {/* Description */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cp-desc">
              Description{' '}
              <span className="text-xs text-muted-foreground font-normal">(optional)</span>
            </Label>
            <Input
              id="cp-desc"
              placeholder="Short description of this platform"
              value={form.description}
              onChange={e => setField('description', e.target.value)}
            />
          </div>

          {/* Logo Initials */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="cp-initials">
              Logo Initials{' '}
              <span className="text-xs text-muted-foreground font-normal">
                (optional, max 3 chars)
              </span>
            </Label>
            <Input
              id="cp-initials"
              placeholder="e.g. MY, NTN"
              maxLength={3}
              value={form.logoInitials}
              onChange={e => setField('logoInitials', e.target.value.toUpperCase())}
            />
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" onClick={handleCancel}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            <Plus className="mr-1.5 h-4 w-4" />
            Add Platform
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
