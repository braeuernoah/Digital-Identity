import { cn } from '../../lib/shadcn/utils'
import { ProfileField, StatItem } from '../data/platformConfig'

type KVProps = {
  fields: ProfileField[]
}

export function ProfileKV({ fields }: KVProps) {
  return (
    <dl className="space-y-2.5">
      {fields.map((field) => (
        <div key={field.label} className="flex gap-3 min-w-0">
          <dt className="text-xs font-medium text-muted-foreground w-[72px] flex-shrink-0 pt-px leading-relaxed">
            {field.label}
          </dt>
          <dd
            className={cn(
              'text-sm text-foreground break-words min-w-0 flex-1 leading-relaxed',
              field.mono && 'font-mono text-xs bg-muted px-1.5 py-0.5 rounded',
              field.sensitive && 'select-all',
            )}
          >
            {field.value || <span className="text-muted-foreground italic">Not set</span>}
          </dd>
        </div>
      ))}
    </dl>
  )
}

type StatsProps = {
  stats: StatItem[]
}

export function ProfileStats({ stats }: StatsProps) {
  if (stats.length === 0) return null
  return (
    <div className="flex flex-wrap gap-2 pt-1">
      {stats.map((s) => (
        <div
          key={s.label}
          className="flex flex-col items-center px-3 py-1.5 rounded-lg bg-muted/60 border border-border/50 min-w-[56px]"
        >
          <span className="text-sm font-semibold text-foreground tabular-nums">{s.value}</span>
          <span className="text-[10px] text-muted-foreground uppercase tracking-wide">{s.label}</span>
        </div>
      ))}
    </div>
  )
}
